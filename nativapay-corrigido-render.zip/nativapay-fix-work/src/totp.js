import { createHmac, randomBytes } from 'node:crypto';
import { safeEqual } from './util.js';

// TOTP (RFC 6238) sem dependências: compatível com Google Authenticator, Authy, 1Password, app Senhas do iPhone.
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const STEP_MS = 30_000;

export function base32Encode(buffer) {
  let bits = 0;
  let value = 0;
  let out = '';
  for (const byte of buffer) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += ALPHABET[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(text) {
  let bits = 0;
  let value = 0;
  const out = [];
  for (const ch of text.replace(/[\s=-]/g, '').toUpperCase()) {
    const index = ALPHABET.indexOf(ch);
    if (index < 0) throw new Error('Segredo base32 inválido.');
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export const generateSecret = () => base32Encode(randomBytes(20));

function codeForStep(secret, step) {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const hmac = createHmac('sha1', base32Decode(secret)).update(counter).digest();
  const offset = hmac[19] & 0xf;
  const binary =
    ((hmac[offset] & 0x7f) << 24) | (hmac[offset + 1] << 16) | (hmac[offset + 2] << 8) | hmac[offset + 3];
  return String(binary % 1_000_000).padStart(6, '0');
}

export const totpNow = (secret, nowMs = Date.now()) => codeForStep(secret, Math.floor(nowMs / STEP_MS));

/** Devolve o "passo" que casou (para impedir reuso do mesmo código) ou null. Aceita ±1 passo de relógio. */
export function verifyTotp(secret, code, nowMs = Date.now(), window = 1) {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return null;
  const current = Math.floor(nowMs / STEP_MS);
  for (let step = current - window; step <= current + window; step++) {
    if (safeEqual(codeForStep(secret, step), code)) return step;
  }
  return null;
}

export const otpauthUrl = (secret, account = 'admin', issuer = 'NativaPay') =>
  `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&digits=6&period=30`;
