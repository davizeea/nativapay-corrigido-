import { dirname, join } from 'node:path';
import { loadConfig } from './config.js';
import { createApp } from './server.js';
import { createBackup } from './backup.js';
import { formatBRL } from './util.js';

let config;
try {
  config = loadConfig();
} catch (err) {
  console.error(err.message);
  console.error('\nCopie .env.example para .env e preencha os valores.');
  process.exit(1);
}

const app = createApp(config);
app.server.listen(config.port, () => {
  console.log(`NativaPay no ar: http://localhost:${config.port}`);
  console.log(`Provedor: ${config.provider} | Taxa por saque: ${formatBRL(config.feeCents)}`);
  console.log(`2FA do admin: ${config.adminTotpSecret ? 'ligado' : 'DESLIGADO (ative com: npm run admin:2fa)'}`);
  if (config.provider === 'mock') console.log('Modo MOCK: nenhum dinheiro real é movimentado.');
});

// Backup automático do banco (cópia consistente, com rotação).
if (config.backupEveryHours > 0) {
  const dir = config.backupDir || join(dirname(config.dbPath), 'backups');
  const runBackup = () => {
    try {
      console.log(`Backup salvo: ${createBackup(app.db, dir, config.backupKeep)}`);
    } catch (err) {
      console.error('Falha no backup:', err.message);
    }
  };
  setTimeout(runBackup, 10_000).unref();
  setInterval(runBackup, config.backupEveryHours * 3600_000).unref();
}

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => app.close().then(() => process.exit(0)));
}
