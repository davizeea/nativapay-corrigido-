import { ProviderError } from '../errors.js';
import { safeEqual } from '../util.js';

/**
 * Adaptador do Asaas: saque por Pix (transferência por chave) e depósito por Pix (cobrança + QR Code).
 * Docs: https://docs.asaas.com
 *
 * Sandbox:  https://api-sandbox.asaas.com/v3   (grátis, ótimo para testar)
 * Produção: https://api.asaas.com/v3
 */
export function createAsaasProvider(config) {
  const { apiKey, baseUrl, webhookToken, userAgent } = config.asaas;

  async function request(method, path, body) {
    let response;
    try {
      response = await fetch(`${baseUrl}${path}`, {
        method,
        headers: {
          'content-type': 'application/json',
          access_token: apiKey,
          'user-agent': userAgent,
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: AbortSignal.timeout(20_000),
      });
    } catch (err) {
      // Rede/timeout: não sabemos o que aconteceu do outro lado.
      throw new ProviderError(`Sem resposta do Asaas: ${err.message}`, { definitive: false });
    }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const reason = data?.errors?.map((e) => e.description).join('; ') || `HTTP ${response.status}`;
      // 4xx = pedido recusado de verdade. 5xx e 408 = resultado incerto.
      const definitive = response.status >= 400 && response.status < 500 && response.status !== 408;
      throw new ProviderError(`Asaas recusou/erro: ${reason}`, { definitive });
    }
    return data;
  }

  // Data de vencimento (YYYY-MM-DD) no horário de Brasília, amanhã: dá folga para quem paga à noite.
  const dueDate = () => new Date(Date.now() - 3 * 3600_000 + 86_400_000).toISOString().slice(0, 10);

  // O Asaas manda datas "YYYY-MM-DD HH:MM:SS" sem fuso (horário de Brasília). Guardamos em UTC (ISO).
  const brasiliaToIso = (text) => {
    if (!text) return null;
    const parsed = new Date(`${String(text).trim().replace(' ', 'T')}-03:00`);
    return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
  };

  return {
    name: 'asaas',

    async transfer({ id, amountCents, pixKey, pixKeyType, description }) {
      const data = await request('POST', '/transfers', {
        value: Number((amountCents / 100).toFixed(2)),
        operationType: 'PIX',
        pixAddressKey: pixKey,
        pixAddressKeyType: pixKeyType,
        description,
        externalReference: id,
      });

      if (data.status === 'FAILED' || data.status === 'CANCELLED') {
        throw new ProviderError(`Transferência ${data.status}: ${data.failReason || 'sem motivo'}`, {
          definitive: true,
        });
      }
      return { externalId: data.id, status: data.status === 'DONE' ? 'COMPLETED' : 'PROCESSING' };
    },

    /** Cria (ou reaproveita) o cliente no Asaas, gera a cobrança Pix e busca o QR Code. */
    async createCharge({ id, amountCents, customer, description }) {
      let customerId = customer.customerId;
      if (!customerId) {
        const created = await request('POST', '/customers', {
          name: customer.name,
          cpfCnpj: customer.cpfCnpj,
          externalReference: String(customer.userId),
          notificationDisabled: true, // o Asaas não manda e-mail/SMS de cobrança para o cliente
        });
        customerId = created.id;
      }

      const payment = await request('POST', '/payments', {
        customer: customerId,
        billingType: 'PIX',
        value: Number((amountCents / 100).toFixed(2)),
        dueDate: dueDate(),
        description,
        externalReference: id,
      });

      const qr = await request('GET', `/payments/${payment.id}/pixQrCode`);
      return {
        externalId: payment.id,
        customerId,
        payload: qr.payload,
        qrImage: qr.encodedImage || null,
        expiresAt: brasiliaToIso(qr.expirationDate),
      };
    },

    // O Asaas manda o token que você cadastrou no webhook no header "asaas-access-token".
    verifyWebhook(headers) {
      return safeEqual(headers['asaas-access-token'], webhookToken);
    },

    parseWebhook(body) {
      if (!body?.event) return null;

      // ----- cobranças (depósitos) -----
      if (body.payment?.id) {
        const map = {
          PAYMENT_RECEIVED: 'PAID', // Pix recebido, com saldo disponível na conta Asaas
          PAYMENT_DELETED: 'CANCELLED',
          PAYMENT_REFUNDED: 'REVERSED',
          PAYMENT_PARTIALLY_REFUNDED: 'REVERSED',
          PAYMENT_CHARGEBACK_REQUESTED: 'REVERSED',
          PAYMENT_RECEIVED_IN_CASH_UNDONE: 'REVERSED',
        };
        const status = map[body.event];
        if (!status) return null; // CREATED, OVERDUE, UPDATED... não mudam nada para nós
        return {
          kind: 'payment',
          eventId: body.id || `${body.payment.id}:${body.event}`,
          externalId: body.payment.id,
          status,
          valueCents: Number.isFinite(body.payment.value) ? Math.round(body.payment.value * 100) : null,
          reason: status === 'REVERSED' ? `Evento ${body.event} no provedor` : null,
        };
      }

      // ----- transferências (saques) -----
      const externalId = body.transfer?.id;
      if (!externalId) return null;
      const map = {
        TRANSFER_DONE: 'COMPLETED',
        TRANSFER_FAILED: 'FAILED',
        TRANSFER_CANCELLED: 'FAILED',
      };
      const status = map[body.event];
      if (!status) return null; // CREATED, PENDING, BLOCKED... não mudam nada no nosso lado
      return {
        kind: 'transfer',
        eventId: body.id || `${externalId}:${body.event}`,
        externalId,
        status,
        reason: body.transfer.failReason || null,
      };
    },
  };
}
