import { createMockProvider } from './mock.js';
import { createAsaasProvider } from './asaas.js';

export function createProvider(config) {
  switch (config.provider) {
    case 'asaas':
      return createAsaasProvider(config);
    case 'mock':
    default:
      return createMockProvider(config);
  }
}
