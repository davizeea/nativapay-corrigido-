import { randomUUID } from 'node:crypto';
import { ProviderError } from '../errors.js';
import { safeEqual } from '../util.js';

/**
 * Provedor de mentira para testar tudo sem gastar nada.
 *
 * Saques (pela chave Pix usada):
 *   - começa com "falha"   -> o Pix é aceito, mas depois FALHA (saldo devolvido)
 *   - começa com "recusa"  -> o provedor recusa na hora (erro definitivo, saldo devolvido)
 *   - começa com "timeout" -> resultado desconhecido (vai para REVIEW, saldo NÃO é devolvido)
 *   - qualquer outra       -> sucesso, confirmado por "webhook" depois de alguns instantes
 *
 * Depósitos: gera um código "copia e cola" falso e marca como PAGO sozinho depois de
 * MOCK_DEPOSIT_DELAY_MS (padrão 8 s). Nenhum dinheiro real é cobrado.
 */
export function createMockProvider(config) {
  const provider = {
    name: 'mock',
    // O servidor liga isto ao tratamento de eventos: ({ kind, externalId, status, ... }) => void
    onEvent: null,

    async transfer({ pixKey }) {
      if (pixKey.startsWith('recusa')) {
        throw new ProviderError('Chave Pix recusada pelo provedor (mock).', { definitive: true });
      }
      if (pixKey.startsWith('timeout')) {
        throw new ProviderError('Timeout falando com o provedor (mock).', { definitive: false });
      }

      const externalId = `mock_${randomUUID()}`;
      const willFail = pixKey.startsWith('falha');

      const timer = setTimeout(() => {
        provider.onEvent?.({
          kind: 'transfer',
          externalId,
          status: willFail ? 'FAILED' : 'COMPLETED',
          reason: willFail ? 'Falha simulada pelo mock' : null,
        });
      }, config.mock.delayMs);
      timer.unref();

      return { externalId, status: 'PROCESSING' };
    },

    async createCharge({ amountCents, customer }) {
      const externalId = `mockpay_${randomUUID()}`;
      const timer = setTimeout(() => {
        provider.onEvent?.({ kind: 'payment', externalId, status: 'PAID', valueCents: amountCents });
      }, config.mock.depositDelayMs);
      timer.unref();

      return {
        externalId,
        customerId: customer.customerId || `mockcus_${randomUUID()}`,
        payload: `00020126MOCK-NATIVAPAY-SIMULADO-${externalId.slice(8, 24)}5204000053039865802BR`,
        qrImage: null,
        expiresAt: new Date(Date.now() + 30 * 60_000).toISOString(),
      };
    },

    verifyWebhook(headers) {
      return safeEqual(headers['x-webhook-token'], config.mock.webhookToken);
    },

    parseWebhook(body) {
      if (!body?.externalId) return null;
      if (body.kind === 'payment') {
        if (!['PAID', 'CANCELLED', 'REVERSED'].includes(body.status)) return null;
        return {
          kind: 'payment',
          eventId: body.eventId || `${body.externalId}:${body.status}`,
          externalId: body.externalId,
          status: body.status,
          valueCents: Number.isInteger(body.valueCents) ? body.valueCents : null,
          reason: body.reason || null,
        };
      }
      if (!['COMPLETED', 'FAILED'].includes(body.status)) return null;
      return {
        kind: 'transfer',
        eventId: body.eventId || `${body.externalId}:${body.status}`,
        externalId: body.externalId,
        status: body.status,
        reason: body.reason || null,
      };
    },
  };
  return provider;
}
