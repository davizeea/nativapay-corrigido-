import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  api_key_hash  TEXT    NOT NULL UNIQUE,
  balance_cents INTEGER NOT NULL DEFAULT 0 CHECK (balance_cents >= 0),
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Extrato: cada movimentação do saldo. amount_cents é assinado (+ entra, - sai).
CREATE TABLE IF NOT EXISTS ledger (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id),
  type         TEXT    NOT NULL CHECK (type IN ('credit', 'withdrawal', 'refund')),
  amount_cents INTEGER NOT NULL,
  ref          TEXT,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger(user_id, id);

CREATE TABLE IF NOT EXISTS withdrawals (
  id                  TEXT    PRIMARY KEY,
  user_id             INTEGER NOT NULL REFERENCES users(id),
  amount_cents        INTEGER NOT NULL,   -- quanto saiu do saldo do usuário
  fee_cents           INTEGER NOT NULL,   -- sua taxa
  net_cents           INTEGER NOT NULL,   -- quanto o usuário recebe (amount - fee)
  provider_cost_cents INTEGER NOT NULL DEFAULT 0,
  pix_key             TEXT    NOT NULL,
  pix_key_type        TEXT    NOT NULL,
  status              TEXT    NOT NULL,   -- PROCESSING | COMPLETED | FAILED | REVIEW
  provider            TEXT    NOT NULL,
  external_id         TEXT,
  idempotency_key     TEXT    NOT NULL,
  error               TEXT,
  created_at          TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, idempotency_key)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_withdrawals_external
  ON withdrawals(provider, external_id) WHERE external_id IS NOT NULL;

-- Depósitos: cobranças Pix para o cliente adicionar saldo.
CREATE TABLE IF NOT EXISTS deposits (
  id              TEXT    PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id),
  amount_cents    INTEGER NOT NULL,
  status          TEXT    NOT NULL,   -- PENDING | PAID | CANCELLED | REVIEW
  provider        TEXT    NOT NULL,
  external_id     TEXT,
  pix_payload     TEXT,               -- "copia e cola"
  qr_image        TEXT,               -- PNG em base64 (quando o provedor devolve)
  expires_at      TEXT,
  idempotency_key TEXT    NOT NULL,
  error           TEXT,
  created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, idempotency_key)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_deposits_external
  ON deposits(provider, external_id) WHERE external_id IS NOT NULL;

-- Chaves Pix salvas pelo cliente (favoritas).
CREATE TABLE IF NOT EXISTS pix_keys (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id),
  label        TEXT    NOT NULL,
  pix_key_type TEXT    NOT NULL,
  pix_key      TEXT    NOT NULL,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, pix_key_type, pix_key)
);

-- Eventos de webhook já processados (evita processar o mesmo evento duas vezes).
CREATE TABLE IF NOT EXISTS webhook_events (
  provider   TEXT NOT NULL,
  event_id   TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (provider, event_id)
);
`;

export function openDb(path) {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  migrate(db);
  return db;
}

/** Acrescenta colunas novas em bancos criados por versões anteriores. */
function migrate(db) {
  const cols = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  // fee_cents NULL = usa a taxa padrão do servidor; número = taxa própria deste cliente
  if (!cols.includes('fee_cents')) db.exec('ALTER TABLE users ADD COLUMN fee_cents INTEGER');
  if (!cols.includes('blocked')) db.exec('ALTER TABLE users ADD COLUMN blocked INTEGER NOT NULL DEFAULT 0');
  // Dados para cobrar por Pix: CPF/CNPJ (só dígitos) e o cadastro do cliente no provedor.
  if (!cols.includes('cpf_cnpj')) db.exec('ALTER TABLE users ADD COLUMN cpf_cnpj TEXT');
  if (!cols.includes('customer_provider')) db.exec('ALTER TABLE users ADD COLUMN customer_provider TEXT');
  if (!cols.includes('customer_id')) db.exec('ALTER TABLE users ADD COLUMN customer_id TEXT');
}

/** Executa fn dentro de uma transação que já trava a escrita (evita saque duplo concorrente). */
export function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
