import { randomBytes } from 'node:crypto';
import { safeEqual, sha256 } from './util.js';
import { verifyTotp } from './totp.js';
import { HttpError } from './errors.js';

const LOCK_MS = 15 * 60_000;
const SESSION_MS = 8 * 3600_000;

/**
 * Proteções do painel e da API:
 *  - trava por IP depois de várias tentativas erradas (chave de admin, chave de cliente, 2FA);
 *  - login do admin com sessão (e 2FA opcional) em vez de mandar a chave a cada requisição.
 * Tudo em memória: reiniciar o servidor limpa as travas e desconecta o admin.
 */
export function createSecurity(config) {
  const fails = new Map(); // ip -> { count, first, lockedUntil }
  const sessions = new Map(); // sha256(token) -> expira em (ms)
  const twoFactor = Boolean(config.adminTotpSecret);
  let lastOtpStep = 0;
  let warnedProxy = false;

  const cleanup = setInterval(() => {
    const now = Date.now();
    for (const [ip, f] of fails) if (now - f.first > LOCK_MS && f.lockedUntil < now) fails.delete(ip);
    for (const [hash, exp] of sessions) if (exp < now) sessions.delete(hash);
  }, 10 * 60_000);
  cleanup.unref();

  return {
    twoFactor,

    /** IP do cliente. Com TRUST_PROXY usa o último item do X-Forwarded-For (o que o SEU proxy anotou). */
    clientIp(req) {
      const forwarded = req.headers['x-forwarded-for'];
      if (forwarded && !config.trustProxy && !warnedProxy) {
        warnedProxy = true;
        console.warn('Aviso: X-Forwarded-For detectado. Se há proxy na frente (Render, Railway...), defina TRUST_PROXY=true.');
      }
      if (config.trustProxy && forwarded) return String(forwarded).split(',').at(-1).trim();
      return req.socket.remoteAddress;
    },

    assertNotLocked(ip) {
      const f = fails.get(ip);
      if (f && f.lockedUntil > Date.now()) {
        const minutes = Math.ceil((f.lockedUntil - Date.now()) / 60_000);
        throw new HttpError(429, 'too_many_attempts', `Muitas tentativas erradas. Tente de novo em ${minutes} min.`);
      }
    },

    recordFailure(ip) {
      const now = Date.now();
      let f = fails.get(ip);
      if (!f || now - f.first > LOCK_MS) f = { count: 0, first: now, lockedUntil: 0 };
      f.count += 1;
      if (f.count >= config.loginMaxFails) f.lockedUntil = now + LOCK_MS;
      fails.set(ip, f);
    },

    recordSuccess(ip) {
      fails.delete(ip);
    },

    /** Valida chave (+ código 2FA) e devolve um token de sessão, ou null. */
    adminLogin(key, otp) {
      if (typeof key !== 'string' || !safeEqual(key, config.adminKey)) return null;
      if (twoFactor) {
        const step = verifyTotp(config.adminTotpSecret, String(otp ?? '').trim());
        if (step === null || step <= lastOtpStep) return null; // errado, vencido ou já usado
        lastOtpStep = step;
      }
      const token = `adm_${randomBytes(32).toString('hex')}`;
      sessions.set(sha256(token), Date.now() + SESSION_MS);
      return { token, expiresInSeconds: SESSION_MS / 1000 };
    },

    isAdmin(req) {
      const session = req.headers['x-admin-session'];
      if (typeof session === 'string' && session) {
        const hash = sha256(session);
        const exp = sessions.get(hash);
        if (exp && exp > Date.now()) return true;
        sessions.delete(hash);
      }
      // A chave pura só vale quando o 2FA está desligado.
      return !twoFactor && safeEqual(req.headers['x-admin-key'], config.adminKey);
    },

    adminLogout(req) {
      const session = req.headers['x-admin-session'];
      if (typeof session === 'string') sessions.delete(sha256(session));
    },
  };
}
