import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const NAME = /^nativapay-\d{8}-\d{6}\.db$/;
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

/** Cópia consistente do banco (VACUUM INTO): pode rodar com o servidor em uso. O arquivo não pode existir. */
function copyTo(db, file) {
  db.prepare('VACUUM INTO ?').run(file);
}

/** Salva um backup em `dir` e apaga os mais antigos, mantendo só os `keep` mais novos. */
export function createBackup(db, dir, keep) {
  mkdirSync(dir, { recursive: true });
  const file = join(dir, `nativapay-${stamp()}.db`);
  copyTo(db, file);
  const all = readdirSync(dir).filter((f) => NAME.test(f)).sort();
  for (const old of all.slice(0, Math.max(all.length - keep, 0))) rmSync(join(dir, old));
  return file;
}

/** Backup em memória, para o admin baixar pelo painel. */
export function backupToBuffer(db) {
  const dir = mkdtempSync(join(tmpdir(), 'nativapay-'));
  try {
    const file = join(dir, 'backup.db');
    copyTo(db, file);
    return readFileSync(file);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
