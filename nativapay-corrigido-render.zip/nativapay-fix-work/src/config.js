import { base32Decode } from './totp.js';

const int = (value, fallback) =>
  value === undefined || value === '' ? fallback : Number.parseInt(value, 10);

/**
 * Todos os valores em dinheiro são em CENTAVOS (inteiros). Nunca use float para dinheiro.
 */
export function loadConfig(env = process.env) {
  const config = {
    port: int(env.PORT, 3000),
    dbPath: env.DB_PATH || './data/gateway.db',
    adminKey: env.ADMIN_KEY,
    // Requisições de API por IP a cada minuto. Atrás de proxy (Render, Replit...) o IP é o do proxy.
    rateLimitPerMin: int(env.RATE_LIMIT, 600),
    // true quando há proxy na frente (Render, Railway, Fly...): usa o IP real do cliente (X-Forwarded-For).
    trustProxy: ['1', 'true'].includes(String(env.TRUST_PROXY).toLowerCase()),
    // Falhas de login/chave por IP antes de travar por 15 minutos.
    loginMaxFails: int(env.LOGIN_MAX_FAILS, 8),
    // Segredo base32 do 2FA do admin (gere com: npm run admin:2fa). Vazio = 2FA desligado.
    adminTotpSecret: env.ADMIN_TOTP_SECRET || null,

    minDepositCents: int(env.MIN_DEPOSIT_CENTS, 500),
    maxDepositCents: int(env.MAX_DEPOSIT_CENTS, 500000),

    backupDir: env.BACKUP_DIR || null, // padrão: <pasta do banco>/backups
    backupEveryHours: int(env.BACKUP_EVERY_HOURS, 24), // 0 desliga
    backupKeep: int(env.BACKUP_KEEP, 7),

    // Sua taxa por saque: 50 = R$ 0,50 | 100 = R$ 1,00
    feeCents: int(env.FEE_CENTS, 50),
    // Quanto o provedor cobra de você por transferência (só para calcular seu lucro real)
    providerCostCents: int(env.PROVIDER_COST_CENTS, 0),

    minWithdrawCents: int(env.MIN_WITHDRAW_CENTS, 1000),
    maxWithdrawCents: int(env.MAX_WITHDRAW_CENTS, 500000),
    dailyLimitCents: int(env.DAILY_LIMIT_CENTS, 1000000),

    provider: env.PROVIDER || 'mock',
    mock: {
      delayMs: int(env.MOCK_DELAY_MS, 600),
      webhookToken: env.MOCK_WEBHOOK_TOKEN || 'mock-token',
      depositDelayMs: int(env.MOCK_DEPOSIT_DELAY_MS, 8000), // o "pagamento" simulado confirma sozinho
    },
    asaas: {
      apiKey: env.ASAAS_API_KEY,
      baseUrl: env.ASAAS_BASE_URL || 'https://api-sandbox.asaas.com/v3',
      webhookToken: env.ASAAS_WEBHOOK_TOKEN,
      userAgent: env.ASAAS_USER_AGENT || 'NativaPay/1.0.0',
    },
  };

  validateConfig(config);
  return config;
}

function validateConfig(c) {
  const errors = [];
  if (!c.adminKey || c.adminKey.length < 16) {
    errors.push('ADMIN_KEY é obrigatória e precisa ter pelo menos 16 caracteres.');
  }
  if (!Number.isInteger(c.feeCents) || c.feeCents < 0) {
    errors.push('FEE_CENTS precisa ser um inteiro >= 0 (ex.: 50 ou 100).');
  }
  if (c.minWithdrawCents <= c.feeCents) {
    errors.push('MIN_WITHDRAW_CENTS precisa ser maior que FEE_CENTS, senão o usuário recebe zero.');
  }
  if (c.maxWithdrawCents < c.minWithdrawCents) {
    errors.push('MAX_WITHDRAW_CENTS precisa ser >= MIN_WITHDRAW_CENTS.');
  }
  if (c.maxDepositCents < c.minDepositCents) {
    errors.push('MAX_DEPOSIT_CENTS precisa ser >= MIN_DEPOSIT_CENTS.');
  }
  if (c.adminTotpSecret) {
    try {
      if (base32Decode(c.adminTotpSecret).length < 10) throw new Error('curto');
    } catch {
      errors.push('ADMIN_TOTP_SECRET inválido. Gere um novo com: npm run admin:2fa');
    }
  }
  if (!['mock', 'asaas'].includes(c.provider)) {
    errors.push('PROVIDER precisa ser "mock" ou "asaas".');
  }
  if (c.provider === 'asaas') {
    if (!c.asaas.apiKey) errors.push('ASAAS_API_KEY é obrigatória com PROVIDER=asaas.');
    if (!c.asaas.webhookToken || c.asaas.webhookToken.length < 16) {
      errors.push('ASAAS_WEBHOOK_TOKEN é obrigatório (mín. 16 caracteres) com PROVIDER=asaas.');
    }
  }
  if (errors.length) {
    throw new Error('Configuração inválida:\n - ' + errors.join('\n - '));
  }
}
