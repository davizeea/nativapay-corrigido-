import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const sha256 = (text) => createHash('sha256').update(text).digest('hex');

export const newApiKey = () => `gw_${randomBytes(24).toString('hex')}`;

/** Comparação de segredos em tempo constante. */
export function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

/** Linha de CSV; neutraliza fórmulas (=, +, -, @) que o Excel/Planilhas executariam. */
export function csvRow(cells) {
  return cells
    .map((cell) => {
      let text = cell === null || cell === undefined ? '' : String(cell);
      // Números puros (ex.: -20.00) ficam como estão para a planilha conseguir somar.
      if (/^[=+\-@\t\r]/.test(text) && !/^-?\d+(\.\d+)?$/.test(text)) text = `'${text}`;
      return /[",\n\r;]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
    })
    .join(',');
}

export const formatBRL = (cents) =>
  (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const PIX_VALIDATORS = {
  CPF: (k) => /^\d{11}$/.test(k),
  CNPJ: (k) => /^\d{14}$/.test(k),
  EMAIL: (k) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(k) && k.length <= 77,
  PHONE: (k) => /^\+?\d{10,13}$/.test(k),
  EVP: (k) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(k),
};

/** Valida CPF (11) ou CNPJ (14) pelos dígitos verificadores. Recebe só dígitos. */
export function isValidCpfCnpj(digits) {
  if (typeof digits !== 'string' || !/^\d+$/.test(digits) || /^(\d)\1+$/.test(digits)) return false;
  const check = (base, weights) => {
    const sum = weights.reduce((acc, w, i) => acc + Number(base[i]) * w, 0);
    const rest = sum % 11;
    return rest < 2 ? 0 : 11 - rest;
  };
  if (digits.length === 11) {
    const d1 = check(digits, [10, 9, 8, 7, 6, 5, 4, 3, 2]);
    const d2 = check(digits, [11, 10, 9, 8, 7, 6, 5, 4, 3, 2]);
    return d1 === Number(digits[9]) && d2 === Number(digits[10]);
  }
  if (digits.length === 14) {
    const d1 = check(digits, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
    const d2 = check(digits, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
    return d1 === Number(digits[12]) && d2 === Number(digits[13]);
  }
  return false;
}

export const PIX_KEY_TYPES = Object.keys(PIX_VALIDATORS);

export function isValidPixKey(type, key) {
  const validator = PIX_VALIDATORS[type];
  return Boolean(validator) && typeof key === 'string' && validator(key);
}
