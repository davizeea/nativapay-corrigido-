import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { openDb } from './db.js';
import { createProvider } from './providers/index.js';
import { createService } from './service.js';
import { createSecurity } from './security.js';
import { backupToBuffer } from './backup.js';
import { HttpError } from './errors.js';

const MAX_BODY_BYTES = 100 * 1024;

// Páginas do site: lista fechada (sem acesso a caminhos arbitrários do disco).
const PUBLIC_FILES = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/admin': ['admin.html', 'text/html; charset=utf-8'],
  '/app': ['app.html', 'text/html; charset=utf-8'],
  '/style.css': ['style.css', 'text/css; charset=utf-8'],
  '/common.js': ['common.js', 'text/javascript; charset=utf-8'],
  '/admin.js': ['admin.js', 'text/javascript; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/logo.svg': ['logo.svg', 'image/svg+xml'],
  '/icon-180.png': ['icon-180.png', 'image/png'],
  '/icon-512.png': ['icon-512.png', 'image/png'],
  '/manifest.webmanifest': ['manifest.webmanifest', 'application/manifest+json'],
};
const STATIC = Object.fromEntries(
  Object.entries(PUBLIC_FILES).map(([route, [file, type]]) => [
    route,
    { body: readFileSync(new URL(`../public/${file}`, import.meta.url)), type },
  ]),
);
const SECURITY_HEADERS = {
  // data: só em imagens: o QR Code do Pix chega como PNG em base64.
  'content-security-policy':
    "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'cache-control': 'no-store',
};

export function createApp(config) {
  const db = openDb(config.dbPath);
  const provider = createProvider(config);
  const service = createService({ db, config, provider });
  const security = createSecurity(config);

  // O mock "avisa" o servidor quando um Pix (saque ou depósito) termina, como um webhook faria.
  let closed = false;
  if (provider.name === 'mock') {
    provider.onEvent = (event) => {
      if (closed) return;
      if (event.kind === 'payment') service.settleDeposit(event);
      else service.settle(event.externalId, event.status, event.reason);
    };
  }

  // Limite simples de requisições por IP (janela de 1 minuto, em memória).
  const hits = new Map();
  setInterval(() => hits.clear(), 60_000).unref();
  const rateLimited = (ip) => {
    const n = (hits.get(ip) ?? 0) + 1;
    hits.set(ip, n);
    return n > config.rateLimitPerMin;
  };

  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const pathname = url.pathname;
      if (req.method === 'GET' && STATIC[pathname]) {
        res.writeHead(200, { 'content-type': STATIC[pathname].type, ...SECURITY_HEADERS });
        return res.end(STATIC[pathname].body);
      }

      const ip = security.clientIp(req);
      if (rateLimited(ip)) {
        throw new HttpError(429, 'rate_limited', 'Muitas requisições. Tente novamente em instantes.');
      }
      const route = `${req.method} ${pathname}`;
      const body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readJson(req) : {};

      // Erro de autenticação: conta a falha (trava o IP depois de várias) e responde 401.
      const unauthorized = (code, message) => {
        security.recordFailure(ip);
        return new HttpError(401, code, message);
      };

      // ---------- públicas ----------
      if (route === 'GET /health') {
        return send(res, 200, { ok: true, provider: provider.name, admin_2fa: security.twoFactor });
      }

      if (route.startsWith('POST /webhooks/')) {
        const name = pathname.split('/')[2];
        if (name !== provider.name) throw new HttpError(404, 'not_found', 'Provedor desconhecido.');
        if (!provider.verifyWebhook(req.headers)) throw new HttpError(401, 'bad_webhook_token', 'Token inválido.');
        const event = provider.parseWebhook(body);
        if (!event) return send(res, 200, { ignored: true }); // o Asaas só aceita HTTP 200
        return send(res, 200, service.handleWebhookEvent(event));
      }

      // ---------- admin ----------
      if (pathname.startsWith('/admin/')) {
        security.assertNotLocked(ip);

        if (route === 'POST /admin/login') {
          const session = security.adminLogin(body.key, body.otp);
          if (!session) {
            throw unauthorized('unauthorized', security.twoFactor ? 'Chave ou código de verificação inválido.' : 'Chave de admin inválida.');
          }
          security.recordSuccess(ip);
          return send(res, 200, { session: session.token, expires_in: session.expiresInSeconds, two_factor: security.twoFactor });
        }
        if (!security.isAdmin(req)) throw unauthorized('unauthorized', 'Sessão ou chave de admin inválida.');

        if (route === 'POST /admin/logout') {
          security.adminLogout(req);
          return send(res, 200, { ok: true });
        }
        if (route === 'POST /admin/users') return send(res, 201, service.createUser(body.name));
        if (route === 'GET /admin/revenue') return send(res, 200, service.revenueReport());
        if (route === 'GET /admin/users') return send(res, 200, { users: service.listUsers() });
        if (route === 'GET /admin/withdrawals.csv') {
          res.writeHead(200, {
            'content-type': 'text/csv; charset=utf-8',
            'content-disposition': 'attachment; filename="nativapay-saques.csv"',
            'cache-control': 'no-store',
          });
          return res.end(service.exportWithdrawalsCsv());
        }
        if (route === 'GET /admin/backup') {
          const day = new Date().toISOString().slice(0, 10);
          res.writeHead(200, {
            'content-type': 'application/octet-stream',
            'content-disposition': `attachment; filename="nativapay-backup-${day}.db"`,
            'cache-control': 'no-store',
          });
          return res.end(backupToBuffer(db));
        }
        const userAction = pathname.match(/^\/admin\/users\/(\d+)\/(fee|block|rotate-key)$/);
        if (userAction && req.method === 'POST') {
          const id = Number(userAction[1]);
          if (userAction[2] === 'fee') return send(res, 200, service.setUserFee(id, body.fee_cents ?? null));
          if (userAction[2] === 'block') return send(res, 200, service.setUserBlocked(id, body.blocked));
          return send(res, 200, service.rotateUserKey(id));
        }
        if (route === 'GET /admin/withdrawals') {
          const status = url.searchParams.get('status');
          return send(res, 200, {
            withdrawals: service.listAllWithdrawals(status, Number(url.searchParams.get('limit')) || 50),
          });
        }
        if (route === 'GET /admin/deposits') {
          const status = url.searchParams.get('status');
          return send(res, 200, {
            deposits: service.listAllDeposits(status, Number(url.searchParams.get('limit')) || 30),
          });
        }
        const resolve = pathname.match(/^\/admin\/withdrawals\/([0-9a-f-]{36})\/resolve$/);
        if (resolve && req.method === 'POST') return send(res, 200, service.resolveReview(resolve[1], body.action));

        const credit = pathname.match(/^\/admin\/users\/(\d+)\/credit$/);
        if (credit && req.method === 'POST') {
          const balance = service.credit(Number(credit[1]), body.amount_cents, body.ref || 'admin');
          return send(res, 200, { balance_cents: balance });
        }
        throw new HttpError(404, 'not_found', 'Rota não encontrada.');
      }

      // ---------- API do cliente (Bearer token) ----------
      if (pathname.startsWith('/v1/')) {
        security.assertNotLocked(ip);
        const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
        const user = service.authenticate(token);
        if (!user) throw unauthorized('unauthorized', 'API key inválida.');

        if (route === 'GET /v1/fee') {
          return send(res, 200, {
            fee_cents: user.fee_cents ?? config.feeCents,
            blocked: Boolean(user.blocked),
            name: user.name,
            has_cpf: Boolean(user.cpf_cnpj),
            min_withdraw_cents: config.minWithdrawCents,
            max_withdraw_cents: config.maxWithdrawCents,
            min_deposit_cents: config.minDepositCents,
            max_deposit_cents: config.maxDepositCents,
          });
        }
        if (route === 'GET /v1/limits') return send(res, 200, service.limits(user.id));
        if (route === 'GET /v1/summary') return send(res, 200, service.summary(user.id));
        if (route === 'GET /v1/pix-keys') return send(res, 200, { keys: service.listPixKeys(user.id) });
        if (route === 'POST /v1/pix-keys') return send(res, 201, service.addPixKey(user.id, body));
        const keyId = pathname.match(/^\/v1\/pix-keys\/(\d+)$/);
        if (keyId && req.method === 'DELETE') return send(res, 200, service.deletePixKey(user.id, Number(keyId[1])));
        if (route === 'GET /v1/ledger.csv') {
          res.writeHead(200, {
            'content-type': 'text/csv; charset=utf-8',
            'content-disposition': 'attachment; filename="nativapay-extrato.csv"',
            'cache-control': 'no-store',
          });
          return res.end(service.statementCsv(user.id));
        }
        if (route === 'GET /v1/balance') {
          return send(res, 200, { balance_cents: service.getBalance(user.id) });
        }
        if (route === 'GET /v1/ledger') {
          return send(res, 200, { entries: service.ledger(user.id, Number(url.searchParams.get('limit')) || 50) });
        }
        if (route === 'POST /v1/deposits') {
          const { deposit, replayed } = await service.createDeposit(user, body, req.headers['idempotency-key']);
          return send(res, replayed ? 200 : 201, deposit);
        }
        if (route === 'GET /v1/deposits') {
          return send(res, 200, { deposits: service.listDeposits(user.id, Number(url.searchParams.get('limit')) || 20) });
        }
        const dep = pathname.match(/^\/v1\/deposits\/([0-9a-f-]{36})$/);
        if (dep && req.method === 'GET') return send(res, 200, service.getDeposit(user.id, dep[1]));

        if (route === 'POST /v1/withdrawals') {
          const { withdrawal, replayed } = await service.requestWithdrawal(user, body, req.headers['idempotency-key']);
          return send(res, replayed ? 200 : 201, withdrawal);
        }
        if (route === 'GET /v1/withdrawals') {
          return send(res, 200, {
            withdrawals: service.listWithdrawals(user.id, Number(url.searchParams.get('limit')) || 50),
          });
        }
        const one = pathname.match(/^\/v1\/withdrawals\/([0-9a-f-]{36})$/);
        if (one && req.method === 'GET') return send(res, 200, service.getWithdrawal(user.id, one[1]));
      }

      throw new HttpError(404, 'not_found', 'Rota não encontrada.');
    } catch (err) {
      if (err instanceof HttpError) return send(res, err.status, { error: err.code, message: err.message });
      console.error('Erro inesperado:', err);
      return send(res, 500, { error: 'internal_error', message: 'Erro interno.' });
    }
  });

  return {
    server,
    service,
    db,
    close: () =>
      new Promise((resolve) => {
        closed = true;
        server.close(() => {
          db.close();
          resolve();
        });
      }),
  };
}

function send(res, status, payload) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new HttpError(413, 'payload_too_large', 'Corpo da requisição grande demais.');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'invalid_json', 'JSON inválido.');
  }
}
