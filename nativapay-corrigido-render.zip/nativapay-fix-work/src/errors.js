export class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/**
 * Erro vindo do provedor de pagamento.
 * definitive=true  -> o provedor RECUSOU claramente (4xx): seguro devolver o saldo.
 * definitive=false -> resultado desconhecido (timeout, 5xx): NÃO devolver automaticamente,
 *                     o dinheiro pode ter saído. Fica em REVIEW para conferência.
 */
export class ProviderError extends Error {
  constructor(message, { definitive }) {
    super(message);
    this.definitive = definitive;
  }
}
