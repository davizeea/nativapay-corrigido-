import { randomUUID } from 'node:crypto';
import { transaction } from './db.js';
import { HttpError, ProviderError } from './errors.js';
import { sha256, newApiKey, isValidPixKey, isValidCpfCnpj, PIX_KEY_TYPES, csvRow } from './util.js';

export function createService({ db, config, provider }) {
  const q = {
    insertUser: db.prepare('INSERT INTO users (name, api_key_hash) VALUES (?, ?) RETURNING id'),
    userById: db.prepare('SELECT id, name, balance_cents, fee_cents, blocked, cpf_cnpj, customer_provider, customer_id, created_at FROM users WHERE id = ?'),
    userByKey: db.prepare('SELECT id, name, balance_cents, fee_cents, blocked, cpf_cnpj, customer_provider, customer_id FROM users WHERE api_key_hash = ?'),
    setFee: db.prepare('UPDATE users SET fee_cents = ? WHERE id = ?'),
    setBlocked: db.prepare('UPDATE users SET blocked = ? WHERE id = ?'),
    setKeyHash: db.prepare('UPDATE users SET api_key_hash = ? WHERE id = ?'),
    addBalance: db.prepare('UPDATE users SET balance_cents = balance_cents + ? WHERE id = ?'),
    insertLedger: db.prepare('INSERT INTO ledger (user_id, type, amount_cents, ref) VALUES (?, ?, ?, ?)'),
    ledgerByUser: db.prepare(
      'SELECT id, type, amount_cents, ref, created_at FROM ledger WHERE user_id = ? ORDER BY id DESC LIMIT ?',
    ),
    wdByIdem: db.prepare('SELECT * FROM withdrawals WHERE user_id = ? AND idempotency_key = ?'),
    wdById: db.prepare('SELECT * FROM withdrawals WHERE id = ?'),
    wdByExternal: db.prepare('SELECT * FROM withdrawals WHERE provider = ? AND external_id = ?'),
    wdByUser: db.prepare('SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?'),
    wdInsert: db.prepare(`
      INSERT INTO withdrawals
        (id, user_id, amount_cents, fee_cents, net_cents, provider_cost_cents,
         pix_key, pix_key_type, status, provider, idempotency_key)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PROCESSING', ?, ?)`),
    wdSetExternal: db.prepare(
      "UPDATE withdrawals SET external_id = ?, updated_at = datetime('now') WHERE id = ?",
    ),
    wdSetStatus: db.prepare(
      "UPDATE withdrawals SET status = ?, error = ?, updated_at = datetime('now') WHERE id = ?",
    ),
    dailyTotal: db.prepare(`
      SELECT COALESCE(SUM(amount_cents), 0) AS total FROM withdrawals
      WHERE user_id = ? AND status != 'FAILED' AND created_at >= datetime('now', '-1 day')`),
    keysList: db.prepare(
      'SELECT id, label, pix_key_type, pix_key, created_at FROM pix_keys WHERE user_id = ? ORDER BY id DESC',
    ),
    keysCount: db.prepare('SELECT COUNT(*) AS n FROM pix_keys WHERE user_id = ?'),
    keyInsert: db.prepare(
      'INSERT INTO pix_keys (user_id, label, pix_key_type, pix_key) VALUES (?, ?, ?, ?) RETURNING id, label, pix_key_type, pix_key, created_at',
    ),
    keyDelete: db.prepare('DELETE FROM pix_keys WHERE id = ? AND user_id = ?'),
    monthSummary: db.prepare(`
      SELECT COUNT(*) AS n, COALESCE(SUM(amount_cents), 0) AS amount, COALESCE(SUM(fee_cents), 0) AS fees
      FROM withdrawals WHERE user_id = ? AND status = 'COMPLETED'
        AND strftime('%Y-%m', updated_at, '-3 hours') = strftime('%Y-%m', 'now', '-3 hours')`),
    allTimeSummary: db.prepare(`
      SELECT COUNT(*) AS n, COALESCE(SUM(amount_cents), 0) AS amount, COALESCE(SUM(fee_cents), 0) AS fees
      FROM withdrawals WHERE user_id = ? AND status = 'COMPLETED'`),
    ledgerAll: db.prepare('SELECT id, type, amount_cents, ref, created_at FROM ledger WHERE user_id = ? ORDER BY id DESC LIMIT 5000'),
    setCpf: db.prepare('UPDATE users SET cpf_cnpj = ? WHERE id = ?'),
    setCustomer: db.prepare('UPDATE users SET customer_provider = ?, customer_id = ? WHERE id = ?'),
    depById: db.prepare('SELECT * FROM deposits WHERE id = ?'),
    depByIdem: db.prepare('SELECT * FROM deposits WHERE user_id = ? AND idempotency_key = ?'),
    depByExternal: db.prepare('SELECT * FROM deposits WHERE provider = ? AND external_id = ?'),
    depByUser: db.prepare('SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?'),
    depPendingCount: db.prepare(
      "SELECT COUNT(*) AS n FROM deposits WHERE user_id = ? AND status = 'PENDING' AND created_at >= datetime('now', '-1 day')",
    ),
    depInsert: db.prepare(
      "INSERT INTO deposits (id, user_id, amount_cents, status, provider, idempotency_key) VALUES (?, ?, ?, 'PENDING', ?, ?)",
    ),
    depSetCharge: db.prepare(
      "UPDATE deposits SET external_id = ?, pix_payload = ?, qr_image = ?, expires_at = ?, updated_at = datetime('now') WHERE id = ?",
    ),
    depSetStatus: db.prepare("UPDATE deposits SET status = ?, error = ?, updated_at = datetime('now') WHERE id = ?"),
    depStats: db.prepare(`
      SELECT
        COALESCE(SUM(CASE WHEN status = 'PAID' THEN 1 ELSE 0 END), 0)            AS paid_count,
        COALESCE(SUM(CASE WHEN status = 'PAID' THEN amount_cents ELSE 0 END), 0) AS paid_cents,
        COALESCE(SUM(CASE WHEN status = 'REVIEW' THEN 1 ELSE 0 END), 0)         AS to_review
      FROM deposits`),
    unseenEvent: db.prepare('DELETE FROM webhook_events WHERE provider = ? AND event_id = ?'),
    seenEvent: db.prepare('INSERT OR IGNORE INTO webhook_events (provider, event_id) VALUES (?, ?)'),
    revenue: db.prepare(`
      SELECT
        COUNT(*)                                   AS withdrawals,
        COALESCE(SUM(amount_cents), 0)             AS volume_cents,
        COALESCE(SUM(fee_cents), 0)                AS fees_cents,
        COALESCE(SUM(provider_cost_cents), 0)      AS provider_cost_cents
      FROM withdrawals WHERE status = 'COMPLETED'`),
    pending: db.prepare(
      "SELECT COUNT(*) AS n, COALESCE(SUM(amount_cents), 0) AS cents FROM withdrawals WHERE status IN ('PROCESSING', 'REVIEW')",
    ),
  };

  const present = (w) =>
    w && {
      id: w.id,
      status: w.status,
      amount_cents: w.amount_cents,
      fee_cents: w.fee_cents,
      net_cents: w.net_cents,
      pix_key_type: w.pix_key_type,
      pix_key: w.pix_key,
      error: w.error,
      created_at: w.created_at,
      updated_at: w.updated_at,
    };

  const presentDeposit = (d, { full = false, admin = false } = {}) =>
    d && {
      id: d.id,
      status: d.status,
      amount_cents: d.amount_cents,
      expires_at: d.expires_at,
      created_at: d.created_at,
      updated_at: d.updated_at,
      ...(full ? { pix_payload: d.pix_payload, qr_image: d.qr_image } : {}),
      ...(admin ? { error: d.error, user_id: d.user_id, user_name: d.user_name, provider: d.provider } : {}),
    };

  return {
    // ---------- usuários ----------
    createUser(name) {
      if (typeof name !== 'string' || name.trim().length < 2 || name.length > 80) {
        throw new HttpError(400, 'invalid_name', 'name precisa ter de 2 a 80 caracteres.');
      }
      const apiKey = newApiKey();
      const { id } = q.insertUser.get(name.trim(), sha256(apiKey));
      // A chave só aparece UMA vez. No banco fica apenas o hash.
      return { id, name: name.trim(), api_key: apiKey };
    },

    authenticate(apiKey) {
      if (typeof apiKey !== 'string' || !apiKey) return null;
      return q.userByKey.get(sha256(apiKey)) ?? null;
    },

    getBalance(userId) {
      return q.userById.get(userId).balance_cents;
    },

    // Em produção o crédito vem de um Pix recebido/venda confirmada. Aqui é manual (admin).
    credit(userId, amountCents, ref = 'admin') {
      if (!Number.isInteger(amountCents) || amountCents <= 0) {
        throw new HttpError(400, 'invalid_amount', 'amount_cents precisa ser um inteiro positivo.');
      }
      return transaction(db, () => {
        if (!q.userById.get(userId)) throw new HttpError(404, 'user_not_found', 'Usuário não existe.');
        q.addBalance.run(amountCents, userId);
        q.insertLedger.run(userId, 'credit', amountCents, ref);
        return q.userById.get(userId).balance_cents;
      });
    },

    ledger(userId, limit = 50) {
      return q.ledgerByUser.all(userId, Math.min(Math.max(limit, 1), 200));
    },

    // ---------- depósitos (adicionar saldo por Pix) ----------
    async createDeposit(user, { amount_cents, cpf_cnpj }, idempotencyKey) {
      if (!idempotencyKey || idempotencyKey.length < 8 || idempotencyKey.length > 100) {
        throw new HttpError(400, 'idempotency_key_required', 'Envie o header Idempotency-Key (8 a 100 caracteres).');
      }
      if (
        !Number.isInteger(amount_cents) ||
        amount_cents < config.minDepositCents ||
        amount_cents > config.maxDepositCents
      ) {
        throw new HttpError(
          400,
          'amount_out_of_range',
          `O depósito deve ficar entre ${config.minDepositCents} e ${config.maxDepositCents} centavos.`,
        );
      }
      let cpf = user.cpf_cnpj;
      if (!cpf) {
        const digits = String(cpf_cnpj ?? '').replace(/\D/g, '');
        if (!isValidCpfCnpj(digits)) {
          throw new HttpError(400, 'invalid_cpf_cnpj', 'Informe um CPF ou CNPJ válido. Ele é exigido para gerar a cobrança Pix.');
        }
        cpf = digits;
      }

      const id = randomUUID();
      const { created, deposit } = transaction(db, () => {
        const existing = q.depByIdem.get(user.id, idempotencyKey);
        if (existing) return { created: false, deposit: existing };
        if (q.depPendingCount.get(user.id).n >= 5) {
          throw new HttpError(429, 'too_many_pending', 'Você já tem Pix em aberto demais. Pague ou aguarde antes de gerar outro.');
        }
        if (!user.cpf_cnpj) q.setCpf.run(cpf, user.id);
        q.depInsert.run(id, user.id, amount_cents, provider.name, idempotencyKey);
        return { created: true, deposit: q.depById.get(id) };
      });
      if (!created) return { deposit: presentDeposit(deposit, { full: true }), replayed: true };

      try {
        const knownCustomer = user.customer_provider === provider.name ? user.customer_id : null;
        const charge = await provider.createCharge({
          id,
          amountCents: amount_cents,
          description: `Depósito NativaPay ${id.slice(0, 8)}`,
          customer: { userId: user.id, name: user.name, cpfCnpj: cpf, customerId: knownCustomer },
        });
        // A imagem vai para <img src="data:...">: só aceita base64 puro.
        const image = typeof charge.qrImage === 'string' && /^[A-Za-z0-9+/=]+$/.test(charge.qrImage) ? charge.qrImage : null;
        q.depSetCharge.run(charge.externalId, charge.payload, image, charge.expiresAt ?? null, id);
        if (charge.customerId && charge.customerId !== knownCustomer) {
          q.setCustomer.run(provider.name, charge.customerId, user.id);
        }
      } catch (err) {
        q.depSetStatus.run('CANCELLED', String(err.message).slice(0, 300), id);
        console.error('Falha ao criar cobrança Pix:', err.message);
        throw new HttpError(502, 'provider_error', 'Não foi possível gerar o Pix agora. Tente novamente em instantes.');
      }
      return { deposit: presentDeposit(q.depById.get(id), { full: true }), replayed: false };
    },

    getDeposit(userId, id) {
      const d = q.depById.get(id);
      if (!d || d.user_id !== userId) throw new HttpError(404, 'not_found', 'Depósito não encontrado.');
      return presentDeposit(d, { full: true });
    },

    listDeposits(userId, limit = 20) {
      return q.depByUser.all(userId, Math.min(Math.max(limit, 1), 100)).map((d) => presentDeposit(d));
    },

    listAllDeposits(status, limit = 30) {
      const rows = db
        .prepare(
          `SELECT d.*, u.name AS user_name FROM deposits d JOIN users u ON u.id = d.user_id
           WHERE (? IS NULL OR d.status = ?) ORDER BY d.created_at DESC, d.rowid DESC LIMIT ?`,
        )
        .all(status || null, status || null, Math.min(Math.max(limit, 1), 200));
      return rows.map((d) => presentDeposit(d, { admin: true }));
    },

    /** Resolve um depósito a partir do aviso do provedor. O crédito acontece uma única vez. */
    settleDeposit({ externalId, status, valueCents = null, reason = null }) {
      return transaction(db, () => {
        const d = q.depByExternal.get(provider.name, externalId);
        if (!d) return { handled: false };

        if (status === 'PAID') {
          if (d.status === 'PAID') return { handled: true, duplicate: true };
          if (d.status === 'REVIEW') return { handled: false };
          if (valueCents !== null && valueCents !== d.amount_cents) {
            q.depSetStatus.run('REVIEW', `Valor recebido (${valueCents}) diferente do cobrado (${d.amount_cents}). Nada foi creditado.`, d.id);
            return { handled: true, review: true };
          }
          q.addBalance.run(d.amount_cents, d.user_id);
          q.insertLedger.run(d.user_id, 'credit', d.amount_cents, `deposit:${d.id}`);
          q.depSetStatus.run('PAID', null, d.id);
          return { handled: true, credited: true };
        }
        if (status === 'CANCELLED') {
          if (d.status === 'PENDING') q.depSetStatus.run('CANCELLED', reason, d.id);
          return { handled: true };
        }
        if (status === 'REVERSED') {
          // O dinheiro já foi creditado e o provedor estornou/contestou: o admin precisa conferir.
          if (d.status === 'PAID') q.depSetStatus.run('REVIEW', reason ?? 'Estorno ou contestação no provedor.', d.id);
          return { handled: true };
        }
        return { handled: false };
      });
    },

    // ---------- chaves Pix salvas ----------
    listPixKeys(userId) {
      return q.keysList.all(userId);
    },

    addPixKey(userId, { label, pix_key_type, pix_key }) {
      const name = typeof label === 'string' ? label.trim() : '';
      if (name.length < 1 || name.length > 30) {
        throw new HttpError(400, 'invalid_label', 'O apelido precisa ter de 1 a 30 caracteres.');
      }
      if (!PIX_KEY_TYPES.includes(pix_key_type) || !isValidPixKey(pix_key_type, pix_key)) {
        throw new HttpError(400, 'invalid_pix_key', 'Chave Pix inválida para o tipo escolhido.');
      }
      if (q.keysCount.get(userId).n >= 10) {
        throw new HttpError(400, 'too_many_keys', 'Você pode salvar até 10 chaves. Remova uma para adicionar outra.');
      }
      try {
        return q.keyInsert.get(userId, name, pix_key_type, pix_key);
      } catch (err) {
        if (/UNIQUE/i.test(err.message)) throw new HttpError(409, 'key_exists', 'Essa chave já está salva.');
        throw err;
      }
    },

    deletePixKey(userId, keyId) {
      if (q.keyDelete.run(keyId, userId).changes === 0) {
        throw new HttpError(404, 'not_found', 'Chave não encontrada.');
      }
      return { deleted: true };
    },

    // ---------- limites, resumo e extrato do cliente ----------
    limits(userId) {
      const { total } = q.dailyTotal.get(userId);
      return {
        daily_limit_cents: config.dailyLimitCents,
        daily_used_cents: total,
        daily_remaining_cents: Math.max(config.dailyLimitCents - total, 0),
      };
    },

    summary(userId) {
      const m = q.monthSummary.get(userId);
      const a = q.allTimeSummary.get(userId);
      return {
        month: { withdrawals: m.n, withdrawn_cents: m.amount, fees_paid_cents: m.fees },
        all_time: { withdrawals: a.n, withdrawn_cents: a.amount, fees_paid_cents: a.fees },
      };
    },

    statementCsv(userId) {
      const reais = (c) => (c / 100).toFixed(2);
      const lines = [
        csvRow(['data_utc', 'tipo', 'valor', 'referencia']),
        ...q.ledgerAll.all(userId).map((e) => csvRow([e.created_at, e.type, reais(e.amount_cents), e.ref])),
      ];
      return '﻿' + lines.join('\r\n') + '\r\n';
    },

    // ---------- saques ----------
    async requestWithdrawal(user, { amount_cents, pix_key, pix_key_type }, idempotencyKey) {
      if (user.blocked) {
        throw new HttpError(403, 'account_blocked', 'Conta bloqueada para saques. Fale com o suporte.');
      }
      if (!idempotencyKey || idempotencyKey.length < 8 || idempotencyKey.length > 100) {
        throw new HttpError(400, 'idempotency_key_required', 'Envie o header Idempotency-Key (8 a 100 caracteres).');
      }
      if (!Number.isInteger(amount_cents)) {
        throw new HttpError(400, 'invalid_amount', 'amount_cents precisa ser um inteiro (centavos).');
      }
      if (amount_cents < config.minWithdrawCents || amount_cents > config.maxWithdrawCents) {
        throw new HttpError(
          400,
          'amount_out_of_range',
          `Valor deve ficar entre ${config.minWithdrawCents} e ${config.maxWithdrawCents} centavos.`,
        );
      }
      if (!PIX_KEY_TYPES.includes(pix_key_type)) {
        throw new HttpError(400, 'invalid_pix_key_type', `pix_key_type deve ser um de: ${PIX_KEY_TYPES.join(', ')}.`);
      }
      if (!isValidPixKey(pix_key_type, pix_key)) {
        throw new HttpError(400, 'invalid_pix_key', `Chave Pix inválida para o tipo ${pix_key_type}.`);
      }

      const fee = user.fee_cents ?? config.feeCents;
      const net = amount_cents - fee;
      if (net <= 0) throw new HttpError(400, 'amount_below_fee', 'O valor precisa ser maior que a taxa.');
      const id = randomUUID();

      // 1) Reserva o saldo e registra o saque, tudo de uma vez (atômico).
      const { created, withdrawal } = transaction(db, () => {
        const existing = q.wdByIdem.get(user.id, idempotencyKey);
        if (existing) return { created: false, withdrawal: existing };

        const { balance_cents } = q.userById.get(user.id);
        if (balance_cents < amount_cents) {
          throw new HttpError(402, 'insufficient_funds', 'Saldo insuficiente.');
        }
        const { total } = q.dailyTotal.get(user.id);
        if (total + amount_cents > config.dailyLimitCents) {
          throw new HttpError(429, 'daily_limit_exceeded', 'Limite diário de saques excedido.');
        }

        q.addBalance.run(-amount_cents, user.id);
        q.insertLedger.run(user.id, 'withdrawal', -amount_cents, id);
        q.wdInsert.run(
          id, user.id, amount_cents, fee, net, config.providerCostCents,
          pix_key, pix_key_type, provider.name, idempotencyKey,
        );
        return { created: true, withdrawal: q.wdById.get(id) };
      });

      // Repetição da mesma requisição: devolve o mesmo saque, sem mover dinheiro de novo.
      if (!created) return { withdrawal: present(withdrawal), replayed: true };

      // 2) Manda o Pix (valor LÍQUIDO) para o provedor. Sua taxa fica com você.
      try {
        const result = await provider.transfer({
          id,
          amountCents: net,
          pixKey: pix_key,
          pixKeyType: pix_key_type,
          description: `Saque ${id.slice(0, 8)}`,
        });
        q.wdSetExternal.run(result.externalId, id);
        if (result.status === 'COMPLETED') this.settle(result.externalId, 'COMPLETED');
      } catch (err) {
        if (err instanceof ProviderError && !err.definitive) {
          // Não sabemos se o Pix saiu. NÃO devolve o saldo: precisa de conferência manual.
          q.wdSetStatus.run('REVIEW', err.message, id);
        } else {
          this.fail(id, err.message);
        }
      }

      return { withdrawal: present(q.wdById.get(id)), replayed: false };
    },

    getWithdrawal(userId, id) {
      const w = q.wdById.get(id);
      if (!w || w.user_id !== userId) throw new HttpError(404, 'not_found', 'Saque não encontrado.');
      return present(w);
    },

    listWithdrawals(userId, limit = 50) {
      return q.wdByUser.all(userId, Math.min(Math.max(limit, 1), 200)).map(present);
    },

    /** Devolve o saldo de um saque que falhou. Só roda uma vez por saque. */
    fail(withdrawalId, reason) {
      return transaction(db, () => {
        const w = q.wdById.get(withdrawalId);
        if (!w || w.status === 'FAILED' || w.status === 'COMPLETED') return false;
        q.addBalance.run(w.amount_cents, w.user_id);
        q.insertLedger.run(w.user_id, 'refund', w.amount_cents, w.id);
        q.wdSetStatus.run('FAILED', reason ?? null, w.id);
        return true;
      });
    },

    /** Resolve um saque a partir da resposta do provedor (webhook ou mock). */
    settle(externalId, status, reason = null) {
      const w = q.wdByExternal.get(provider.name, externalId);
      if (!w) return { handled: false };
      if (status === 'COMPLETED') {
        if (w.status === 'FAILED') return { handled: false }; // já devolvemos o saldo; vai para conferência
        q.wdSetStatus.run('COMPLETED', null, w.id);
        return { handled: true };
      }
      this.fail(w.id, reason);
      return { handled: true };
    },

    /** Processa um evento de webhook com proteção contra duplicidade. */
    handleWebhookEvent(event) {
      const isPayment = event.kind === 'payment';
      // Evento de algo que ainda não conhecemos: não marca como visto.
      const known = isPayment
        ? q.depByExternal.get(provider.name, event.externalId)
        : q.wdByExternal.get(provider.name, event.externalId);
      if (!known) return { handled: false };

      const { changes } = q.seenEvent.run(provider.name, event.eventId);
      if (changes === 0) return { duplicate: true };
      try {
        return isPayment ? this.settleDeposit(event) : this.settle(event.externalId, event.status, event.reason);
      } catch (err) {
        // Falhou no meio: libera o evento para o provedor poder reenviar e tentarmos de novo.
        q.unseenEvent.run(provider.name, event.eventId);
        throw err;
      }
    },

    // ---------- painel admin ----------
    listUsers() {
      return db
        .prepare(
          `SELECT id, name, balance_cents, fee_cents, blocked, created_at FROM users ORDER BY id DESC LIMIT 500`,
        )
        .all()
        .map((u) => ({ ...u, blocked: Boolean(u.blocked), effective_fee_cents: u.fee_cents ?? config.feeCents }));
    },

    /** fee_cents = null volta para a taxa padrão. */
    setUserFee(userId, feeCents) {
      if (feeCents !== null && (!Number.isInteger(feeCents) || feeCents < 0 || feeCents >= config.minWithdrawCents)) {
        throw new HttpError(400, 'invalid_fee', `A taxa deve ser um inteiro de 0 até ${config.minWithdrawCents - 1} centavos.`);
      }
      if (!q.userById.get(userId)) throw new HttpError(404, 'user_not_found', 'Usuário não existe.');
      q.setFee.run(feeCents, userId);
      return { fee_cents: feeCents, effective_fee_cents: feeCents ?? config.feeCents };
    },

    setUserBlocked(userId, blocked) {
      if (typeof blocked !== 'boolean') throw new HttpError(400, 'invalid_blocked', 'blocked deve ser true ou false.');
      if (!q.userById.get(userId)) throw new HttpError(404, 'user_not_found', 'Usuário não existe.');
      q.setBlocked.run(blocked ? 1 : 0, userId);
      return { blocked };
    },

    /** Gera uma chave nova; a antiga deixa de funcionar na hora. */
    rotateUserKey(userId) {
      if (!q.userById.get(userId)) throw new HttpError(404, 'user_not_found', 'Usuário não existe.');
      const apiKey = newApiKey();
      q.setKeyHash.run(sha256(apiKey), userId);
      return { api_key: apiKey };
    },

    exportWithdrawalsCsv() {
      const rows = db
        .prepare(
          `SELECT w.*, u.name AS user_name FROM withdrawals w JOIN users u ON u.id = w.user_id
           ORDER BY w.created_at DESC, w.rowid DESC LIMIT 10000`,
        )
        .all();
      const reais = (c) => (c / 100).toFixed(2);
      const lines = [
        csvRow(['id', 'data_utc', 'cliente', 'status', 'valor', 'taxa', 'liquido', 'tipo_chave', 'chave_pix', 'provedor', 'erro']),
        ...rows.map((w) =>
          csvRow([w.id, w.created_at, w.user_name, w.status, reais(w.amount_cents), reais(w.fee_cents),
            reais(w.net_cents), w.pix_key_type, w.pix_key, w.provider, w.error]),
        ),
      ];
      return '﻿' + lines.join('\r\n') + '\r\n'; // BOM: o Excel abre os acentos certo
    },

    listAllWithdrawals(status, limit = 50) {
      const rows = db
        .prepare(
          `SELECT w.*, u.name AS user_name FROM withdrawals w JOIN users u ON u.id = w.user_id
           WHERE (? IS NULL OR w.status = ?) ORDER BY w.created_at DESC, w.rowid DESC LIMIT ?`,
        )
        .all(status || null, status || null, Math.min(Math.max(limit, 1), 200));
      return rows.map((w) => ({ ...present(w), user_id: w.user_id, user_name: w.user_name, provider: w.provider }));
    },

    /** Saque em REVIEW: o admin confere no provedor e decide. */
    resolveReview(withdrawalId, action) {
      if (!['complete', 'refund'].includes(action)) {
        throw new HttpError(400, 'invalid_action', 'action deve ser "complete" ou "refund".');
      }
      return transaction(db, () => {
        const w = q.wdById.get(withdrawalId);
        if (!w) throw new HttpError(404, 'not_found', 'Saque não encontrado.');
        if (w.status !== 'REVIEW') throw new HttpError(409, 'not_in_review', 'Só saques em revisão podem ser resolvidos.');
        if (action === 'complete') {
          q.wdSetStatus.run('COMPLETED', null, w.id);
        } else {
          q.addBalance.run(w.amount_cents, w.user_id);
          q.insertLedger.run(w.user_id, 'refund', w.amount_cents, w.id);
          q.wdSetStatus.run('FAILED', 'Devolvido manualmente pelo admin', w.id);
        }
        return present(q.wdById.get(w.id));
      });
    },

    // ---------- relatório ----------
    revenueReport() {
      const r = q.revenue.get();
      const p = q.pending.get();

      // Taxas dos últimos 7 dias no horário de Brasília (UTC-3), com dias sem saque zerados.
      const BR = 3 * 3600 * 1000;
      const rows = db
        .prepare(
          `SELECT date(updated_at, '-3 hours') AS day, SUM(fee_cents) AS fees, COUNT(*) AS n
           FROM withdrawals WHERE status = 'COMPLETED' AND updated_at >= datetime('now', '-8 days')
           GROUP BY day`,
        )
        .all();
      const byDay = new Map(rows.map((r) => [r.day, r]));
      const daily = [];
      for (let i = 6; i >= 0; i--) {
        const day = new Date(Date.now() - BR - i * 86400000).toISOString().slice(0, 10);
        daily.push({ day, fees_cents: byDay.get(day)?.fees ?? 0, count: byDay.get(day)?.n ?? 0 });
      }
      const dep = q.depStats.get();
      return {
        deposits: { paid_count: dep.paid_count, paid_cents: dep.paid_cents, to_review: dep.to_review },
        daily,
        completed_withdrawals: r.withdrawals,
        volume_cents: r.volume_cents,
        fees_collected_cents: r.fees_cents,
        provider_cost_cents: r.provider_cost_cents,
        profit_cents: r.fees_cents - r.provider_cost_cents,
        in_flight: { count: p.n, amount_cents: p.cents },
      };
    },
  };
}
