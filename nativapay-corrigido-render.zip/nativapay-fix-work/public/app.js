let token = store.get('gw_key');
let fee = { fee_cents: 0, min_withdraw_cents: 0, max_withdraw_cents: 0 };
let pendingKey = null; // mesma Idempotency-Key se o cliente tentar de novo após erro de rede
let pollTimer;
let balanceCents = 0;
let remainingCents = Infinity;
let savedKeys = [];
let ledgerEntries = [];
let ledgerFilter = 'all';
let openReceipt = null;
let depKey = null; // Idempotency-Key do depósito em andamento
let payPoll;
let payId = null;

const auth = () => ({ authorization: `Bearer ${token}` });
const PIX_LABEL = { CPF: 'CPF', CNPJ: 'CNPJ', EMAIL: 'E-mail', PHONE: 'Celular', EVP: 'Chave aleatória' };

function maskKey(key) {
  if (key.includes('@')) {
    const [user, domain] = key.split('@');
    return `${user.slice(0, 2)}•••@${domain}`;
  }
  return key.length > 6 ? `${key.slice(0, 3)}•••${key.slice(-2)}` : key;
}

function show(loggedIn) {
  $('#login').classList.toggle('hidden', loggedIn);
  $('#panel').classList.toggle('hidden', !loggedIn);
}

function logout() {
  hidePay();
  token = null;
  store.del('gw_key');
  clearTimeout(pollTimer);
  show(false);
}

async function refresh() {
  clearTimeout(pollTimer);
  try {
    const [bal, wds, led, lim, sum, keys, deps] = await Promise.all([
      api('GET', '/v1/balance', { headers: auth() }),
      api('GET', '/v1/withdrawals?limit=200', { headers: auth() }),
      api('GET', '/v1/ledger?limit=60', { headers: auth() }),
      api('GET', '/v1/limits', { headers: auth() }),
      api('GET', '/v1/summary', { headers: auth() }),
      api('GET', '/v1/pix-keys', { headers: auth() }),
      api('GET', '/v1/deposits?limit=10', { headers: auth() }),
    ]);
    balanceCents = bal.balance_cents;
    remainingCents = lim.daily_remaining_cents;
    savedKeys = keys.keys;
    ledgerEntries = led.entries;
    $('#balance').textContent = brl(bal.balance_cents);
    $('#remaining').textContent = brl(lim.daily_remaining_cents);
    $('#month').textContent = brl(sum.month.withdrawn_cents);
    $('#monthfees').textContent = brl(sum.month.fees_paid_cents);
    renderWithdrawals(wds.withdrawals.slice(0, 20));
    renderDeposits(deps.deposits);
    renderLedger();
    renderKeys();
    updatePreview();
    if (wds.withdrawals.some((w) => w.status === 'PROCESSING')) pollTimer = setTimeout(refresh, 4000);
  } catch (err) {
    if (err.status === 401) { logout(); toast('Sessão inválida. Entre novamente.', true); } else toast(err.message, true);
  }
}

function renderWithdrawals(list) {
  const box = $('#withdrawals');
  box.replaceChildren();
  if (!list.length) return box.append(h('p', { class: 'muted' }, 'Você ainda não fez nenhum saque.'));
  for (const w of list) {
    box.append(h('button', { class: 'itembtn', type: 'button', onclick: () => showReceipt(w) },
      h('div', { class: 'row' }, h('span', { class: 'amount' }, brl(w.amount_cents)), badge(w.status)),
      h('div', { class: 'muted' }, `Recebe ${brl(w.net_cents)} · taxa ${brl(w.fee_cents)} · ${fmtDate(w.created_at)}`),
      w.status === 'FAILED' ? h('div', { class: 'muted' }, 'Valor devolvido ao saldo.') : '',
      w.status === 'REVIEW' ? h('div', { class: 'muted' }, 'Em conferência. Fale com o suporte se demorar.') : '',
      h('div', { class: 'hint' }, 'Toque para ver o comprovante')));
  }
}

function renderLedger() {
  const box = $('#ledger');
  box.replaceChildren();
  const list = ledgerEntries.filter((e) =>
    ledgerFilter === 'all' || (ledgerFilter === 'in' ? e.amount_cents >= 0 : e.amount_cents < 0));
  if (!list.length) return box.append(h('p', { class: 'muted' }, 'Sem movimentações.'));
  for (const e of list) {
    box.append(h('div', { class: 'item row' },
      h('div', {}, h('div', {}, entryLabel(e)), h('div', { class: 'muted' }, fmtDate(e.created_at))),
      h('span', { class: 'amount ' + (e.amount_cents >= 0 ? 'plus' : 'minus') },
        (e.amount_cents >= 0 ? '+' : '−') + brl(Math.abs(e.amount_cents)))));
  }
}

// ---------- depósito por Pix ----------
const isExpired = (d) => d.expires_at && parseDate(d.expires_at).getTime() < Date.now();

function renderDeposits(list) {
  $('#deposits-section').classList.toggle('hidden', !list.length);
  const box = $('#deposits');
  box.replaceChildren();
  for (const d of list) {
    const open = d.status === 'PENDING' && !isExpired(d);
    box.append(h('div', { class: 'item row' },
      h('div', {}, h('div', { class: 'amount' }, brl(d.amount_cents)), h('div', { class: 'muted' }, fmtDate(d.created_at))),
      open
        ? h('button', { class: 'small', type: 'button', onclick: (ev) => run(ev.currentTarget, async () => showPay(await api('GET', `/v1/deposits/${d.id}`, { headers: auth() }))) }, 'Ver Pix')
        : badge(d.status)));
  }
}

function hidePay() {
  clearTimeout(payPoll);
  payId = null;
  $('#pay').classList.add('hidden');
}

function showPay(d) {
  payId = d.id;
  $('#pay').classList.remove('hidden');
  $('#payamount').textContent = brl(d.amount_cents);
  $('#paycode').textContent = d.pix_payload || '';
  const qr = $('#qr');
  if (d.qr_image) { qr.src = `data:image/png;base64,${d.qr_image}`; qr.classList.remove('hidden'); } else { qr.removeAttribute('src'); qr.classList.add('hidden'); }
  $('#payexp').textContent = d.expires_at ? `Válido até ${fmtDate(d.expires_at)}` : '';
  $('#paystatus').replaceChildren(badge(d.status));
  $('#pay').scrollIntoView({ behavior: 'smooth', block: 'start' });
  clearTimeout(payPoll);
  if (d.status === 'PENDING') payPoll = setTimeout(() => pollPay(d.id), 3000);
}

async function pollPay(id) {
  if (payId !== id || !token) return;
  try {
    const d = await api('GET', `/v1/deposits/${id}`, { headers: auth() });
    if (payId !== id) return;
    $('#paystatus').replaceChildren(badge(d.status));
    if (d.status === 'PENDING') { payPoll = setTimeout(() => pollPay(id), 3000); return; }
    if (d.status === 'PAID') { toast(`Pagamento recebido! +${brl(d.amount_cents)}`); setTimeout(hidePay, 2500); } else toast('Este Pix não está mais disponível.', true);
    refresh();
  } catch (err) {
    if (err.status === 401) logout(); else payPoll = setTimeout(() => pollPay(id), 6000);
  }
}

$('#dep-form').addEventListener('submit', (ev) => {
  ev.preventDefault();
  const cents = parseBRL($('#damount').value);
  if (!cents) return toast('Informe um valor válido.', true);
  run($('#dep-btn'), async () => {
    const body = { amount_cents: cents };
    if (!fee.has_cpf) body.cpf_cnpj = $('#cpf').value.replace(/\D/g, '');
    const signature = JSON.stringify(body);
    if (!depKey || depKey.signature !== signature) depKey = { id: uuid(), signature };
    try {
      const d = await api('POST', '/v1/deposits', { headers: { ...auth(), 'idempotency-key': depKey.id }, body });
      depKey = null;
      if (!fee.has_cpf) { fee.has_cpf = true; $('#cpf-wrap').classList.add('hidden'); }
      $('#dep-form').reset();
      showPay(d);
      refresh();
    } catch (err) {
      if (err.status) depKey = null;
      throw err;
    }
  });
});

$('#copycode').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText($('#paycode').textContent); toast('Código Pix copiado. Cole no app do seu banco.'); }
  catch { toast('Toque e segure no código para copiar.', true); }
});
$('#payclose').addEventListener('click', hidePay);

function renderKeys() {
  $('#keys-section').classList.toggle('hidden', !savedKeys.length);
  $('#saved-wrap').classList.toggle('hidden', !savedKeys.length);

  const select = $('#saved');
  const current = select.value;
  select.replaceChildren(
    h('option', { value: '' }, 'Digitar outra chave'),
    ...savedKeys.map((k) => h('option', { value: String(k.id) }, `${k.label} · ${maskKey(k.pix_key)}`)));
  if (savedKeys.some((k) => String(k.id) === current)) select.value = current;

  const box = $('#keys');
  box.replaceChildren();
  for (const k of savedKeys) {
    box.append(h('div', { class: 'keyrow' },
      h('div', {}, h('div', { class: 'amount' }, k.label),
        h('div', { class: 'muted' }, `${PIX_LABEL[k.pix_key_type]} · ${maskKey(k.pix_key)}`)),
      h('div', { class: 'actions' },
        h('button', { class: 'small', type: 'button', onclick: () => useKey(k) }, 'Usar'),
        h('button', { class: 'small ghost', type: 'button', 'aria-label': `Remover ${k.label}`,
          onclick: (ev) => {
            if (!confirm(`Remover a chave "${k.label}"?`)) return;
            run(ev.currentTarget, async () => {
              await api('DELETE', `/v1/pix-keys/${k.id}`, { headers: auth() });
              toast('Chave removida.');
              refresh();
            });
          } }, 'Remover'))));
  }
}

function useKey(k) {
  $('#ktype').value = k.pix_key_type;
  $('#pix').value = k.pix_key;
  $('#saved').value = String(k.id);
  $('#nick-wrap').classList.add('hidden');
  $('#nick').value = '';
  $('#wd-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
  $('#amount').focus();
}

// ---------- comprovante ----------
function receiptText(w) {
  return [
    'NativaPay · Comprovante de saque',
    `Valor: ${brl(w.amount_cents)}`,
    `Taxa: ${brl(w.fee_cents)}`,
    `Valor enviado: ${brl(w.net_cents)}`,
    `Chave Pix (${PIX_LABEL[w.pix_key_type]}): ${maskKey(w.pix_key)}`,
    `Situação: ${STATUS_LABEL[w.status] || w.status}`,
    `Data: ${fmtDate(w.created_at)}`,
    `Código: ${w.id}`,
  ].join('\n');
}

function showReceipt(w) {
  openReceipt = w;
  const line = (label, value, big) => h('div', { class: 'rline' + (big ? ' big' : '') }, h('span', {}, label), h('span', {}, value));
  $('#receipt-body').replaceChildren(
    line('Valor do saque', brl(w.amount_cents), true),
    line('Taxa', brl(w.fee_cents)),
    line('Valor enviado', brl(w.net_cents)),
    line('Chave Pix', `${PIX_LABEL[w.pix_key_type]} · ${maskKey(w.pix_key)}`),
    line('Situação', STATUS_LABEL[w.status] || w.status),
    line('Data', fmtDate(w.created_at)),
    line('Código', w.id));
  $('#receipt').showModal();
}

$('#r-close').addEventListener('click', () => $('#receipt').close());
$('#r-share').addEventListener('click', async () => {
  if (!openReceipt) return;
  const text = receiptText(openReceipt);
  try {
    if (navigator.share) await navigator.share({ title: 'Comprovante NativaPay', text });
    else { await navigator.clipboard.writeText(text); toast('Comprovante copiado.'); }
  } catch (err) {
    if (err.name === 'AbortError') return; // o cliente fechou a folha de compartilhamento
    try { await navigator.clipboard.writeText(text); toast('Comprovante copiado.'); } catch { toast('Não foi possível compartilhar.', true); }
  }
});
$('#r-repeat').addEventListener('click', () => {
  if (!openReceipt) return;
  const w = openReceipt;
  $('#receipt').close();
  $('#ktype').value = w.pix_key_type;
  $('#pix').value = w.pix_key;
  $('#amount').value = (w.amount_cents / 100).toFixed(2).replace('.', ',');
  $('#saved').value = '';
  updatePreview();
  $('#wd-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
});

// ---------- formulário de saque ----------
function updatePreview() {
  const cents = parseBRL($('#amount').value);
  const box = $('#preview');
  if (!cents) { box.textContent = 'Digite o valor para ver quanto você recebe.'; return; }
  const net = cents - fee.fee_cents;
  if (net <= 0) box.textContent = 'Valor menor que a taxa.';
  else if (cents > balanceCents) box.textContent = `Saldo insuficiente. Você tem ${brl(balanceCents)}.`;
  else if (cents > remainingCents) box.textContent = `Acima do limite de hoje (${brl(remainingCents)} restantes).`;
  else box.textContent = `Taxa de ${brl(fee.fee_cents)} → você recebe ${brl(net)} (mínimo ${brl(fee.min_withdraw_cents)})`;
}

async function login(key) {
  token = key.trim();
  fee = await api('GET', '/v1/fee', { headers: auth() }); // valida a chave
  store.set('gw_key', token);
  $('#hello').textContent = `Olá, ${fee.name}`;
  $('#feeinfo').textContent = brl(fee.fee_cents);
  $('#blocked').classList.toggle('hidden', !fee.blocked);
  $('#cpf-wrap').classList.toggle('hidden', fee.has_cpf);
  api('GET', '/health').then((h) => $('#mocknote').classList.toggle('hidden', h.provider !== 'mock')).catch(() => {});
  show(true);
  refresh();
}

$('#login-form').addEventListener('submit', (ev) => {
  ev.preventDefault();
  run(ev.submitter, async () => {
    try { await login($('#key').value); } catch (err) {
      token = null;
      throw err.status === 401 ? new Error('Chave de acesso inválida.') : err;
    }
    $('#key').value = '';
  });
});

$('#amount').addEventListener('input', updatePreview);
$('#logout').addEventListener('click', logout);

for (const btn of document.querySelectorAll('[data-pct]')) {
  btn.addEventListener('click', () => {
    const cents = Math.floor((balanceCents * Number(btn.dataset.pct)) / 100);
    $('#amount').value = (cents / 100).toFixed(2).replace('.', ',');
    updatePreview();
  });
}

$('#saved').addEventListener('change', () => {
  const k = savedKeys.find((x) => String(x.id) === $('#saved').value);
  if (k) useKey(k);
  else { $('#pix').value = ''; $('#nick-wrap').classList.remove('hidden'); }
});

$('#ledger-filters').addEventListener('click', (ev) => {
  const chip = ev.target.closest('.chip');
  if (!chip) return;
  ledgerFilter = chip.dataset.f;
  for (const c of document.querySelectorAll('#ledger-filters .chip')) c.setAttribute('aria-pressed', String(c === chip));
  renderLedger();
});

$('#export').addEventListener('click', (ev) => run(ev.currentTarget, async () => {
  const res = await fetch('/v1/ledger.csv', { headers: auth() });
  if (!res.ok) throw new Error('Não foi possível exportar.');
  const url = URL.createObjectURL(await res.blob());
  const a = h('a', { href: url, download: 'nativapay-extrato.csv' });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  toast('Extrato exportado.');
}));

$('#wd-form').addEventListener('submit', (ev) => {
  ev.preventDefault();
  const cents = parseBRL($('#amount').value);
  if (!cents) return toast('Informe um valor válido.', true);
  run($('#wd-btn'), async () => {
    const body = { amount_cents: cents, pix_key: $('#pix').value.trim(), pix_key_type: $('#ktype').value };
    // A mesma chave só é reaproveitada se o pedido for idêntico ao que falhou por rede.
    const signature = JSON.stringify(body);
    if (!pendingKey || pendingKey.signature !== signature) pendingKey = { id: uuid(), signature };
    const nick = $('#nick').value.trim();
    try {
      const w = await api('POST', '/v1/withdrawals', { headers: { ...auth(), 'idempotency-key': pendingKey.id }, body });
      pendingKey = null;
      $('#wd-form').reset();
      $('#nick-wrap').classList.remove('hidden');
      if (nick && !savedKeys.some((k) => k.pix_key === body.pix_key && k.pix_key_type === body.pix_key_type)) {
        await api('POST', '/v1/pix-keys', {
          headers: auth(), body: { label: nick, pix_key: body.pix_key, pix_key_type: body.pix_key_type },
        }).then(() => toast(`Saque solicitado! Chave "${nick}" salva.`))
          .catch((err) => toast(`Saque solicitado, mas a chave não foi salva: ${err.message}`, true));
      } else {
        toast(w.status === 'FAILED' ? 'O provedor recusou o saque. Valor devolvido.' : 'Saque solicitado!', w.status === 'FAILED');
      }
      refresh();
    } catch (err) {
      if (err.status) pendingKey = null; // o servidor respondeu: pode gerar nova chave na próxima
      throw err;
    }
  });
});

if (token) {
  login(token).catch(() => logout());
}
