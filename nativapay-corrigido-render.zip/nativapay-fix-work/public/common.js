// Utilidades compartilhadas. Todo texto vindo da API entra na página via textContent (sem innerHTML).
const brl = (cents) => (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const $ = (selector) => document.querySelector(selector);

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) el.append(kid instanceof Node ? kid : String(kid));
  return el;
}

const store = {
  get: (k) => { try { return sessionStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { sessionStorage.setItem(k, v); } catch { /* modo privado */ } },
  del: (k) => { try { sessionStorage.removeItem(k); } catch { /* ignora */ } },
};

async function api(method, path, { headers = {}, body } = {}) {
  const res = await fetch(path, {
    method,
    headers: { 'content-type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw Object.assign(new Error(data.message || `Erro ${res.status}`), { status: res.status, code: data.error });
  }
  return data;
}

let toastTimer;
function toast(message, bad = false) {
  document.querySelector('.toast')?.remove();
  const el = h('div', { class: 'toast' + (bad ? ' bad' : ''), role: 'status' }, message);
  document.body.append(el);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.remove(), 4000);
}

const STATUS_LABEL = {
  PROCESSING: 'Processando', COMPLETED: 'Concluído', FAILED: 'Falhou', REVIEW: 'Em revisão',
  PENDING: 'Aguardando', PAID: 'Pago', CANCELLED: 'Cancelado',
};
const badge = (status) => h('span', { class: `badge ${status}` }, STATUS_LABEL[status] || status);

const TYPE_LABEL = { credit: 'Crédito', withdrawal: 'Saque', refund: 'Estorno' };
const entryLabel = (e) => (e.type === 'credit' && String(e.ref).startsWith('deposit:') ? 'Depósito Pix' : TYPE_LABEL[e.type] || e.type);

// Aceita "YYYY-MM-DD HH:MM:SS" (SQLite, UTC) e ISO "...T...Z".
const parseDate = (text) => new Date(/T/.test(text) ? text : text.replace(' ', 'T') + 'Z');
const fmtDate = (text) => parseDate(text).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

/** "12,50" -> 1250 | "1.000,50" -> 100050 | "12.5" -> 1250. Retorna null se inválido. */
function parseBRL(text) {
  let s = String(text).trim().replace(/[R$\s]/g, '');
  if (!s) return null;
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (!/^\d+\.\d{1,2}$/.test(s)) s = s.replace(/\./g, '');
  const value = Number(s);
  if (!Number.isFinite(value) || value <= 0) return null;
  return Math.round(value * 100);
}

const uuid = () =>
  crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;

/** Roda uma ação desabilitando o botão e mostrando erros como aviso. */
async function run(button, fn) {
  button.disabled = true;
  try { await fn(); } catch (err) { toast(err.message, true); } finally { button.disabled = false; }
}
