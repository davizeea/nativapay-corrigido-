let session = store.get('gw_admin'); // token de sessão (a chave de admin nunca fica guardada)
let allUsers = [];
let statusFilter = '';
const auth = () => ({ 'x-admin-session': session });

function show(loggedIn) {
  $('#login').classList.toggle('hidden', loggedIn);
  $('#panel').classList.toggle('hidden', !loggedIn);
}

function logout() {
  if (session) api('POST', '/admin/logout', { headers: auth(), body: {} }).catch(() => {});
  session = null;
  store.del('gw_admin');
  show(false);
  loadHealth();
}

// A tela de login pergunta o código de 6 dígitos só quando o 2FA está ligado.
async function loadHealth() {
  try {
    const h = await api('GET', '/health');
    $('#otp-wrap').classList.toggle('hidden', !h.admin_2fa);
    $('#testtag').classList.toggle('hidden', h.provider !== 'mock');
    $('#twofa').textContent = h.admin_2fa ? 'Ligada' : 'Desligada';
    $('#twofa').className = 'badge ' + (h.admin_2fa ? 'COMPLETED' : 'FAILED');
    $('#twofa-help').textContent = h.admin_2fa
      ? 'O login pede a chave e um código de 6 dígitos do seu app autenticador.'
      : 'Recomendado: rode "npm run admin:2fa" no servidor e siga as instruções para ligar.';
  } catch { /* sem rede: mostra o formulário simples */ }
}

async function refresh() {
  try {
    const statusQuery = statusFilter ? `&status=${statusFilter}` : '';
    const [rev, users, wds, reviews, deps] = await Promise.all([
      api('GET', '/admin/revenue', { headers: auth() }),
      api('GET', '/admin/users', { headers: auth() }),
      api('GET', `/admin/withdrawals?limit=30${statusQuery}`, { headers: auth() }),
      api('GET', '/admin/withdrawals?status=REVIEW&limit=50', { headers: auth() }),
      api('GET', '/admin/deposits?limit=20', { headers: auth() }),
    ]);
    allUsers = users.users;
    renderRevenue(rev);
    renderUsers();
    renderWithdrawals(wds.withdrawals);
    renderReview(reviews.withdrawals);
    renderDeposits(deps.deposits);
  } catch (err) {
    if (err.status === 401) { logout(); toast('Sessão expirada. Entre novamente.', true); } else toast(err.message, true);
  }
}

function renderRevenue(r) {
  $('#profit').textContent = brl(r.profit_cents);
  $('#fees').textContent = brl(r.fees_collected_cents);
  $('#cost').textContent = brl(r.provider_cost_cents);
  $('#count').textContent = String(r.completed_withdrawals);
  $('#volume').textContent = brl(r.volume_cents);
  $('#inflight').textContent = `${r.in_flight.count} · ${brl(r.in_flight.amount_cents)}`;
  $('#liability').textContent = brl(allUsers.reduce((sum, u) => sum + u.balance_cents, 0));
  $('#deposits').textContent = `${r.deposits.paid_count} · ${brl(r.deposits.paid_cents)}`;

  const max = Math.max(...r.daily.map((d) => d.fees_cents), 1);
  $('#chart').replaceChildren(...r.daily.map((d) => {
    const bar = h('div', { class: 'bar' + (d.fees_cents ? '' : ' zero') });
    bar.style.height = `${Math.max((d.fees_cents / max) * 80, 3)}%`; // CSSOM é permitido pela CSP
    const [, month, day] = d.day.split('-');
    return h('div', { class: 'col', title: `${day}/${month}: ${brl(d.fees_cents)} em ${d.count} saque(s)` },
      h('span', { class: 'val' }, d.fees_cents ? brl(d.fees_cents).replace('R$', '').trim() : ''), bar,
      h('small', {}, `${day}/${month}`));
  }));
}

function userRow(u) {
  const feeInput = h('input', {
    inputmode: 'decimal', placeholder: `Padrão (${brl(u.effective_fee_cents)})`,
    value: u.fee_cents === null ? '' : (u.fee_cents / 100).toFixed(2).replace('.', ','),
    'aria-label': 'Taxa própria em reais',
  });
  const keyOut = h('div', { class: 'keybox hidden' });

  const saveFee = h('button', {
    class: 'small',
    onclick: (ev) => run(ev.currentTarget, async () => {
      const text = feeInput.value.trim();
      const fee = text === '' ? null : /^0([.,]0+)?$/.test(text) ? 0 : parseBRL(text);
      if (text !== '' && fee === null) throw new Error('Taxa inválida.');
      const r = await api('POST', `/admin/users/${u.id}/fee`, { headers: auth(), body: { fee_cents: fee } });
      toast(`Taxa de ${u.name}: ${brl(r.effective_fee_cents)}${fee === null ? ' (padrão)' : ''}`);
      refresh();
    }),
  }, 'Salvar taxa');

  const toggleBlock = h('button', {
    class: 'small ' + (u.blocked ? '' : 'danger'),
    onclick: (ev) => {
      if (!u.blocked && !confirm(`Bloquear saques de ${u.name}?`)) return;
      run(ev.currentTarget, async () => {
        await api('POST', `/admin/users/${u.id}/block`, { headers: auth(), body: { blocked: !u.blocked } });
        toast(u.blocked ? 'Cliente desbloqueado.' : 'Cliente bloqueado.');
        refresh();
      });
    },
  }, u.blocked ? 'Desbloquear' : 'Bloquear saques');

  const rotate = h('button', {
    class: 'small ghost',
    onclick: (ev) => {
      if (!confirm(`Gerar nova chave para ${u.name}? A chave atual para de funcionar agora.`)) return;
      run(ev.currentTarget, async () => {
        const r = await api('POST', `/admin/users/${u.id}/rotate-key`, { headers: auth(), body: {} });
        keyOut.textContent = r.api_key;
        keyOut.classList.remove('hidden');
        toast('Nova chave gerada. Copie agora.');
      });
    },
  }, 'Gerar nova chave');

  return h('details', { class: 'user' },
    h('summary', {},
      h('div', {},
        h('div', {}, u.name, ' ', u.blocked ? h('span', { class: 'badge FAILED' }, 'Bloqueado') : ''),
        h('div', { class: 'muted' }, `#${u.id} · taxa ${brl(u.effective_fee_cents)}${u.fee_cents === null ? '' : ' (própria)'}`)),
      h('span', { class: 'amount' }, brl(u.balance_cents))),
    h('div', { class: 'user-body stack' },
      h('div', {}, h('label', {}, 'Taxa própria (vazio = padrão)'), h('div', { class: 'inline' }, feeInput, saveFee)),
      h('div', { class: 'row' }, toggleBlock, rotate),
      keyOut));
}

function renderUsers() {
  const term = $('#search').value.trim().toLowerCase();
  const list = allUsers.filter((u) => !term || u.name.toLowerCase().includes(term) || String(u.id) === term.replace('#', ''));
  const box = $('#users');
  box.replaceChildren();
  if (!list.length) box.append(h('p', { class: 'muted' }, allUsers.length ? 'Nenhum cliente encontrado.' : 'Nenhum cliente ainda.'));
  for (const u of list) box.append(userRow(u));

  const select = $('#cuser');
  const current = select.value;
  select.replaceChildren(...allUsers.map((u) => h('option', { value: String(u.id) }, `${u.name} (#${u.id})`)));
  if (current) select.value = current;
}

function withdrawalLine(w) {
  return h('div', {},
    h('div', { class: 'row' }, h('span', { class: 'amount' }, `${brl(w.amount_cents)} · ${w.user_name}`), badge(w.status)),
    h('div', { class: 'muted' }, `Líquido ${brl(w.net_cents)} · taxa ${brl(w.fee_cents)} · ${fmtDate(w.created_at)}`),
    h('div', { class: 'muted' }, `${w.pix_key_type}: ${w.pix_key}`),
    w.error ? h('div', { class: 'muted' }, w.error) : '');
}

function renderWithdrawals(list) {
  const box = $('#withdrawals');
  box.replaceChildren();
  if (!list.length) box.append(h('p', { class: 'muted' }, 'Nenhum saque encontrado.'));
  for (const w of list) box.append(h('div', { class: 'item' }, withdrawalLine(w)));
}

function renderDeposits(list) {
  $('#dep-review').classList.toggle('hidden', !list.some((d) => d.status === 'REVIEW'));
  const box = $('#deposit-list');
  box.replaceChildren();
  if (!list.length) return box.append(h('p', { class: 'muted' }, 'Nenhum depósito ainda.'));
  for (const d of list) {
    box.append(h('div', { class: 'item' },
      h('div', { class: 'row' }, h('span', { class: 'amount' }, `${brl(d.amount_cents)} · ${d.user_name}`), badge(d.status)),
      h('div', { class: 'muted' }, fmtDate(d.created_at)),
      d.error ? h('div', { class: 'muted' }, d.error) : ''));
  }
}

function renderReview(list) {
  $('#review-section').classList.toggle('hidden', !list.length);
  const box = $('#review');
  box.replaceChildren();
  for (const w of list) {
    const resolve = (action, label) => h('button', {
      class: 'small ' + (action === 'refund' ? 'ghost' : ''),
      onclick: (ev) => {
        const text = action === 'complete'
          ? 'Confirma que o Pix JÁ SAIU no provedor?'
          : 'Confirma que o Pix NÃO saiu? O valor será devolvido ao cliente.';
        if (!confirm(text)) return;
        run(ev.currentTarget, async () => {
          await api('POST', `/admin/withdrawals/${w.id}/resolve`, { headers: auth(), body: { action } });
          toast(action === 'complete' ? 'Marcado como concluído.' : 'Saldo devolvido.');
          refresh();
        });
      },
    }, label);
    box.append(h('div', { class: 'item stack' }, withdrawalLine(w),
      h('div', { class: 'row' }, resolve('complete', 'O Pix saiu'), resolve('refund', 'Não saiu: devolver'))));
  }
}

async function enter() {
  show(true);
  loadHealth();
  refresh();
}

$('#login-form').addEventListener('submit', (ev) => {
  ev.preventDefault();
  run(ev.submitter, async () => {
    const r = await api('POST', '/admin/login', { body: { key: $('#key').value.trim(), otp: $('#otp').value.trim() } });
    session = r.session;
    store.set('gw_admin', session);
    $('#key').value = '';
    $('#otp').value = '';
    enter();
  });
});

$('#logout').addEventListener('click', logout);
$('#search').addEventListener('input', renderUsers);

$('#filters').addEventListener('click', (ev) => {
  const chip = ev.target.closest('.chip');
  if (!chip) return;
  statusFilter = chip.dataset.status;
  for (const c of document.querySelectorAll('#filters .chip')) c.setAttribute('aria-pressed', String(c === chip));
  refresh();
});

$('#export').addEventListener('click', (ev) => run(ev.currentTarget, async () => {
  const res = await fetch('/admin/withdrawals.csv', { headers: auth() });
  if (!res.ok) throw new Error('Não foi possível exportar.');
  const url = URL.createObjectURL(await res.blob());
  const a = h('a', { href: url, download: 'nativapay-saques.csv' });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  toast('CSV gerado.');
}));

$('#user-form').addEventListener('submit', (ev) => {
  ev.preventDefault();
  run(ev.submitter, async () => {
    const user = await api('POST', '/admin/users', { headers: auth(), body: { name: $('#uname').value.trim() } });
    $('#newkey-value').textContent = user.api_key;
    $('#newkey').classList.remove('hidden');
    $('#uname').value = '';
    toast(`Cliente ${user.name} criado.`);
    refresh();
  });
});

$('#copy').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('#newkey-value').textContent);
    toast('Chave copiada.');
  } catch {
    toast('Toque e segure na chave para copiar.', true);
  }
});

$('#credit-form').addEventListener('submit', (ev) => {
  ev.preventDefault();
  const cents = parseBRL($('#camount').value);
  if (!cents) return toast('Informe um valor válido.', true);
  run(ev.submitter, async () => {
    const r = await api('POST', `/admin/users/${$('#cuser').value}/credit`, {
      headers: auth(), body: { amount_cents: cents, ref: 'painel-admin' },
    });
    $('#camount').value = '';
    toast(`Creditado. Novo saldo: ${brl(r.balance_cents)}`);
    refresh();
  });
});

$('#backup').addEventListener('click', (ev) => run(ev.currentTarget, async () => {
  const res = await fetch('/admin/backup', { headers: auth() });
  if (!res.ok) throw new Error('Não foi possível gerar o backup.');
  const url = URL.createObjectURL(await res.blob());
  const a = h('a', { href: url, download: `nativapay-backup-${new Date().toISOString().slice(0, 10)}.db` });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  toast('Backup baixado.');
}));

loadHealth();
if (session) {
  api('GET', '/admin/revenue', { headers: auth() }).then(enter).catch(logout);
}
