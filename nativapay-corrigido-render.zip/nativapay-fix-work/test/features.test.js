import { test } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdtempSync, writeFileSync, existsSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/server.js';
import { createBackup } from '../src/backup.js';
import { createAsaasProvider } from '../src/providers/asaas.js';
import { totpNow, verifyTotp, generateSecret } from '../src/totp.js';
import { isValidCpfCnpj } from '../src/util.js';

const ADMIN = 'admin-key-for-tests-123456';
const CPF = '52998224725';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function makeApp(overrides = {}) {
  const config = loadConfig({
    ADMIN_KEY: ADMIN,
    DB_PATH: ':memory:',
    FEE_CENTS: '50',
    MOCK_DELAY_MS: '40',
    MOCK_DEPOSIT_DELAY_MS: '60',
    LOGIN_MAX_FAILS: '1000',
    ...overrides,
  });
  const app = createApp(config);
  await new Promise((resolve) => app.server.listen(0, resolve));
  const base = `http://localhost:${app.server.address().port}`;
  const call = async (method, path, { body, headers = {} } = {}) => {
    const res = await fetch(base + path, {
      method,
      headers: { 'content-type': 'application/json', ...headers },
      body: body ? JSON.stringify(body) : undefined,
    });
    const raw = await res.arrayBuffer();
    let data = {};
    try { data = JSON.parse(Buffer.from(raw).toString('utf8')); } catch { /* binário/CSV */ }
    return { status: res.status, data, raw: Buffer.from(raw), headers: res.headers };
  };
  const admin = (method, path, body) => call(method, path, { body, headers: { 'x-admin-key': ADMIN } });
  async function newUser(name = 'Cliente') {
    const { data } = await admin('POST', '/admin/users', { name });
    const auth = { authorization: `Bearer ${data.api_key}` };
    return {
      id: data.id,
      get: (path) => call('GET', path, { headers: auth }),
      post: (path, body, idem = randomUUID()) => call('POST', path, { body, headers: { ...auth, 'idempotency-key': idem } }),
    };
  }
  return { app, base, call, admin, newUser, config };
}

async function waitFor(fn, label) {
  for (let i = 0; i < 80; i++) {
    const v = await fn();
    if (v) return v;
    await sleep(25);
  }
  throw new Error(`Timeout esperando: ${label}`);
}

// ---------- depósitos ----------

test('depósito: valida dados, gera Pix, credita sozinho uma única vez', async () => {
  const { app, admin, newUser } = await makeApp();
  try {
    const user = await newUser('Ana');
    assert.equal((await user.post('/v1/deposits', { amount_cents: 2000, cpf_cnpj: '123' })).data.error, 'invalid_cpf_cnpj');
    assert.equal((await user.post('/v1/deposits', { amount_cents: 100, cpf_cnpj: CPF })).data.error, 'amount_out_of_range');
    assert.equal((await user.post('/v1/deposits', { amount_cents: 2000, cpf_cnpj: CPF }, '')).data.error, 'idempotency_key_required');

    const key = randomUUID();
    const created = await user.post('/v1/deposits', { amount_cents: 2000, cpf_cnpj: '529.982.247-25' }, key);
    assert.equal(created.status, 201);
    assert.equal(created.data.status, 'PENDING');
    assert.ok(created.data.pix_payload.length > 20);

    const replay = await user.post('/v1/deposits', { amount_cents: 2000, cpf_cnpj: CPF }, key);
    assert.equal(replay.status, 200);
    assert.equal(replay.data.id, created.data.id);

    await waitFor(async () => (await user.get(`/v1/deposits/${created.data.id}`)).data.status === 'PAID', 'depósito pago');
    assert.equal((await user.get('/v1/balance')).data.balance_cents, 2000);
    const ledger = (await user.get('/v1/ledger')).data.entries;
    assert.equal(ledger[0].ref, `deposit:${created.data.id}`);

    // o CPF ficou salvo: o segundo depósito não pede de novo
    assert.equal((await user.get('/v1/fee')).data.has_cpf, true);
    assert.equal((await user.post('/v1/deposits', { amount_cents: 1000 })).status, 201);

    const report = (await admin('GET', '/admin/revenue')).data;
    assert.equal(report.deposits.paid_count, 1);
    assert.equal(report.deposits.paid_cents, 2000);
    assert.ok((await admin('GET', '/admin/deposits')).data.deposits.some((d) => d.user_name === 'Ana'));
  } finally {
    await app.close();
  }
});

test('depósito: webhook duplicado não credita duas vezes; valor errado e estorno vão para REVIEW', async () => {
  const { app, call, newUser } = await makeApp({ MOCK_DEPOSIT_DELAY_MS: '600000' });
  try {
    const user = await newUser('Beto');
    const dep = (await user.post('/v1/deposits', { amount_cents: 3000, cpf_cnpj: CPF })).data;
    const externalId = app.db.prepare('SELECT external_id FROM deposits WHERE id = ?').get(dep.id).external_id;
    const hook = (body, token = 'mock-token') =>
      call('POST', '/webhooks/mock', { body: { kind: 'payment', externalId, ...body }, headers: { 'x-webhook-token': token } });

    assert.equal((await hook({ status: 'PAID', valueCents: 3000 }, 'errado')).status, 401);
    assert.equal((await hook({ status: 'PAID', valueCents: 3000, eventId: 'e1' })).data.credited, true);
    assert.equal((await hook({ status: 'PAID', valueCents: 3000, eventId: 'e1' })).data.duplicate, true); // mesmo evento
    assert.equal((await hook({ status: 'PAID', valueCents: 3000, eventId: 'e2' })).data.duplicate, true); // evento novo, já pago
    assert.equal((await user.get('/v1/balance')).data.balance_cents, 3000);

    await hook({ status: 'REVERSED', eventId: 'e3' });
    assert.equal((await user.get(`/v1/deposits/${dep.id}`)).data.status, 'REVIEW');

    const other = (await user.post('/v1/deposits', { amount_cents: 5000 })).data;
    const otherExt = app.db.prepare('SELECT external_id FROM deposits WHERE id = ?').get(other.id).external_id;
    const wrong = await call('POST', '/webhooks/mock', {
      body: { kind: 'payment', externalId: otherExt, status: 'PAID', valueCents: 123 },
      headers: { 'x-webhook-token': 'mock-token' },
    });
    assert.equal(wrong.data.review, true);
    assert.equal((await user.get('/v1/balance')).data.balance_cents, 3000); // nada creditado
  } finally {
    await app.close();
  }
});

test('depósito: cliente não enxerga o depósito de outro', async () => {
  const { app, newUser } = await makeApp({ MOCK_DEPOSIT_DELAY_MS: '600000' });
  try {
    const a = await newUser('Alice');
    const b = await newUser('Bruno');
    const dep = (await a.post('/v1/deposits', { amount_cents: 1000, cpf_cnpj: CPF })).data;
    assert.equal((await b.get(`/v1/deposits/${dep.id}`)).status, 404);
  } finally {
    await app.close();
  }
});

// ---------- segurança ----------

test('admin: login com sessão (sem 2FA) e logout', async () => {
  const { app, call } = await makeApp();
  try {
    assert.equal((await call('POST', '/admin/login', { body: { key: 'errada' } })).status, 401);
    const ok = await call('POST', '/admin/login', { body: { key: ADMIN } });
    assert.equal(ok.status, 200);
    const session = { 'x-admin-session': ok.data.session };
    assert.equal((await call('GET', '/admin/revenue', { headers: session })).status, 200);
    await call('POST', '/admin/logout', { headers: session, body: {} });
    assert.equal((await call('GET', '/admin/revenue', { headers: session })).status, 401);
  } finally {
    await app.close();
  }
});

test('admin: com 2FA a chave pura não vale e o código não pode ser reutilizado', async () => {
  const secret = generateSecret();
  const { app, call } = await makeApp({ ADMIN_TOTP_SECRET: secret });
  try {
    assert.equal((await call('GET', '/health')).data.admin_2fa, true);
    assert.equal((await call('GET', '/admin/revenue', { headers: { 'x-admin-key': ADMIN } })).status, 401);
    assert.equal((await call('POST', '/admin/login', { body: { key: ADMIN, otp: '000000' } })).status, 401);
    assert.equal((await call('POST', '/admin/login', { body: { key: ADMIN } })).status, 401);

    const code = totpNow(secret);
    const ok = await call('POST', '/admin/login', { body: { key: ADMIN, otp: code } });
    assert.equal(ok.status, 200);
    assert.equal((await call('GET', '/admin/revenue', { headers: { 'x-admin-session': ok.data.session } })).status, 200);
    // o mesmo código não entra duas vezes
    assert.equal((await call('POST', '/admin/login', { body: { key: ADMIN, otp: code } })).status, 401);
  } finally {
    await app.close();
  }
});

test('trava por IP depois de várias tentativas erradas', async () => {
  const { app, call, newUser } = await makeApp({ LOGIN_MAX_FAILS: '3' });
  try {
    for (let i = 0; i < 3; i++) assert.equal((await call('POST', '/admin/login', { body: { key: 'x' } })).status, 401);
    const locked = await call('POST', '/admin/login', { body: { key: ADMIN } }); // até a chave certa fica bloqueada
    assert.equal(locked.status, 429);
    assert.equal(locked.data.error, 'too_many_attempts');
    assert.equal((await call('GET', '/v1/balance', { headers: { authorization: 'Bearer nada' } })).status, 429);
    assert.equal((await call('GET', '/health')).status, 200); // o resto do site continua no ar
    assert.ok(newUser);
  } finally {
    await app.close();
  }
});

test('backup: admin baixa um banco SQLite válido; rotação mantém só os mais novos', async () => {
  const { app, admin, call } = await makeApp();
  try {
    assert.equal((await call('GET', '/admin/backup')).status, 401);
    const res = await admin('GET', '/admin/backup');
    assert.equal(res.status, 200);
    assert.equal(res.raw.subarray(0, 15).toString('latin1'), 'SQLite format 3');

    const dir = mkdtempSync(join(tmpdir(), 'bk-'));
    for (const n of ['20200101-000000', '20200102-000000', '20200103-000000']) writeFileSync(join(dir, `nativapay-${n}.db`), 'x');
    writeFileSync(join(dir, 'outro-arquivo.txt'), 'não mexer');
    const file = createBackup(app.db, dir, 2);
    assert.ok(existsSync(file));
    const left = readdirSync(dir).sort();
    assert.equal(left.filter((f) => f.endsWith('.db')).length, 2);
    assert.ok(left.includes('outro-arquivo.txt'));
    rmSync(dir, { recursive: true, force: true });
  } finally {
    await app.close();
  }
});

test('TOTP segue o vetor oficial da RFC 6238 e CPF/CNPJ validam dígitos', () => {
  const rfcSecret = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';
  assert.equal(totpNow(rfcSecret, 59_000), '287082');
  assert.notEqual(verifyTotp(rfcSecret, '287082', 59_000), null);
  assert.equal(verifyTotp(rfcSecret, '287082', 59_000 + 120_000), null); // fora da janela
  assert.equal(isValidCpfCnpj('52998224725'), true);
  assert.equal(isValidCpfCnpj('52998224726'), false);
  assert.equal(isValidCpfCnpj('11111111111'), false);
  assert.equal(isValidCpfCnpj('11222333000181'), true);
});

// ---------- adaptador do Asaas (chamadas HTTP simuladas) ----------

function asaasWithFakeFetch(handler) {
  const calls = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init = {}) => {
    const call = { url: String(url), method: init.method, body: init.body ? JSON.parse(init.body) : undefined, headers: init.headers };
    calls.push(call);
    const { status = 200, json } = handler(call);
    return { ok: status < 400, status, json: async () => json };
  };
  const provider = createAsaasProvider({
    asaas: { apiKey: 'chave-secreta', baseUrl: 'https://asaas.test/v3', webhookToken: 'tok-1234567890123456', userAgent: 'NativaPay/test' },
  });
  return { provider, calls, restore: () => { globalThis.fetch = realFetch; } };
}

test('Asaas: cria cliente, cobrança Pix e busca o QR Code; reaproveita o cliente', async () => {
  const fake = asaasWithFakeFetch(({ url, method }) => {
    if (url.endsWith('/customers') && method === 'POST') return { json: { id: 'cus_1' } };
    if (url.endsWith('/payments') && method === 'POST') return { json: { id: 'pay_1', status: 'PENDING' } };
    if (url.endsWith('/payments/pay_1/pixQrCode')) return { json: { encodedImage: 'iVBORw0KGgo=', payload: '000201PIX', expirationDate: '2026-12-01 23:59:59' } };
    return { status: 404, json: {} };
  });
  try {
    const first = await fake.provider.createCharge({
      id: 'dep-1', amountCents: 2550, description: 'Depósito',
      customer: { userId: 7, name: 'Ana', cpfCnpj: CPF, customerId: null },
    });
    assert.deepEqual(
      fake.calls.map((c) => `${c.method} ${c.url.replace('https://asaas.test/v3', '')}`),
      ['POST /customers', 'POST /payments', 'GET /payments/pay_1/pixQrCode'],
    );
    assert.equal(fake.calls[0].headers.access_token, 'chave-secreta');
    assert.deepEqual(
      { name: fake.calls[0].body.name, cpfCnpj: fake.calls[0].body.cpfCnpj, notificationDisabled: fake.calls[0].body.notificationDisabled },
      { name: 'Ana', cpfCnpj: CPF, notificationDisabled: true },
    );
    assert.equal(fake.calls[1].body.billingType, 'PIX');
    assert.equal(fake.calls[1].body.value, 25.5);
    assert.equal(fake.calls[1].body.customer, 'cus_1');
    assert.equal(fake.calls[1].body.externalReference, 'dep-1');
    assert.match(fake.calls[1].body.dueDate, /^\d{4}-\d{2}-\d{2}$/);
    assert.equal(first.payload, '000201PIX');
    assert.equal(first.customerId, 'cus_1');
    assert.equal(first.expiresAt, '2026-12-02T02:59:59.000Z'); // 23:59 em Brasília = 02:59 UTC do dia seguinte

    fake.calls.length = 0;
    await fake.provider.createCharge({
      id: 'dep-2', amountCents: 1000, description: 'x',
      customer: { userId: 7, name: 'Ana', cpfCnpj: CPF, customerId: 'cus_1' },
    });
    assert.ok(!fake.calls.some((c) => c.url.endsWith('/customers')), 'não recria o cliente');
  } finally {
    fake.restore();
  }
});

test('Asaas: recusa do provedor vira ProviderError definitivo; webhooks são interpretados', async () => {
  const fake = asaasWithFakeFetch(() => ({ status: 400, json: { errors: [{ description: 'CPF inválido' }] } }));
  try {
    await assert.rejects(
      fake.provider.createCharge({ id: 'd', amountCents: 1000, description: 'x', customer: { userId: 1, name: 'A', cpfCnpj: CPF } }),
      (err) => err.definitive === true && /CPF inválido/.test(err.message),
    );
  } finally {
    fake.restore();
  }

  const { provider } = asaasWithFakeFetch(() => ({ json: {} }));
  assert.equal(provider.verifyWebhook({ 'asaas-access-token': 'tok-1234567890123456' }), true);
  assert.equal(provider.verifyWebhook({ 'asaas-access-token': 'outro' }), false);

  const paid = provider.parseWebhook({ id: 'evt_1', event: 'PAYMENT_RECEIVED', payment: { id: 'pay_1', value: 25.5 } });
  assert.deepEqual(paid, { kind: 'payment', eventId: 'evt_1', externalId: 'pay_1', status: 'PAID', valueCents: 2550, reason: null });
  assert.equal(provider.parseWebhook({ event: 'PAYMENT_OVERDUE', payment: { id: 'pay_1', value: 1 } }), null);
  assert.equal(provider.parseWebhook({ event: 'PAYMENT_CREATED', payment: { id: 'pay_1', value: 1 } }), null);
  assert.equal(provider.parseWebhook({ id: 'e2', event: 'PAYMENT_REFUNDED', payment: { id: 'pay_1', value: 1 } }).status, 'REVERSED');
  assert.equal(provider.parseWebhook({ id: 'e3', event: 'TRANSFER_DONE', transfer: { id: 'tra_1' } }).kind, 'transfer');
  assert.equal(provider.parseWebhook({ event: 'TRANSFER_PENDING', transfer: { id: 'tra_1' } }), null);
});
