import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/server.js';

const ADMIN = 'admin-key-for-tests-123456';

function makeApp(overrides = {}) {
  const config = loadConfig({
    ADMIN_KEY: ADMIN,
    DB_PATH: ':memory:',
    FEE_CENTS: '50',
    PROVIDER_COST_CENTS: '10',
    MIN_WITHDRAW_CENTS: '1000',
    MOCK_DELAY_MS: '40',
    MOCK_DEPOSIT_DELAY_MS: '60',
    LOGIN_MAX_FAILS: '1000',
    ...overrides,
  });
  const app = createApp(config);
  return new Promise((resolve) =>
    app.server.listen(0, () => resolve({ app, base: `http://localhost:${app.server.address().port}` })),
  );
}

function client(base) {
  const call = async (method, path, { body, headers = {} } = {}) => {
    const res = await fetch(base + path, {
      method,
      headers: { 'content-type': 'application/json', ...headers },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { status: res.status, data: await res.json() };
  };
  const admin = (method, path, body) => call(method, path, { body, headers: { 'x-admin-key': ADMIN } });

  async function newUser(name = 'Davi', balance = 0) {
    const { data } = await admin('POST', '/admin/users', { name });
    if (balance) await admin('POST', `/admin/users/${data.id}/credit`, { amount_cents: balance });
    const auth = { authorization: `Bearer ${data.api_key}` };
    return {
      id: data.id,
      get: (path) => call('GET', path, { headers: auth }),
      withdraw: (body, key = randomUUID()) =>
        call('POST', '/v1/withdrawals', { body, headers: { ...auth, 'idempotency-key': key } }),
    };
  }
  return { call, admin, newUser };
}

const pix = (key) => ({ amount_cents: 2000, pix_key: key, pix_key_type: 'EMAIL' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitStatus(user, id, expected) {
  for (let i = 0; i < 50; i++) {
    const { data } = await user.get(`/v1/withdrawals/${id}`);
    if (data.status === expected) return data;
    await sleep(20);
  }
  throw new Error(`Saque ${id} não chegou em ${expected}`);
}

let ctx, api;
before(async () => {
  ctx = await makeApp();
  api = client(ctx.base);
});
after(() => ctx.app.close());

test('desconta a taxa de R$ 0,50 e envia o valor líquido', async () => {
  const user = await api.newUser('Ana', 5000);
  const { status, data } = await user.withdraw(pix('ana@teste.com'));

  assert.equal(status, 201);
  assert.equal(data.amount_cents, 2000);
  assert.equal(data.fee_cents, 50);
  assert.equal(data.net_cents, 1950);

  await waitStatus(user, data.id, 'COMPLETED');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 3000);
});

test('taxa de R$ 1,00 também funciona', async () => {
  const other = await makeApp({ FEE_CENTS: '100' });
  try {
    const c = client(other.base);
    const user = await c.newUser('Bia', 5000);
    const { data } = await user.withdraw(pix('bia@teste.com'));
    assert.equal(data.fee_cents, 100);
    assert.equal(data.net_cents, 1900);
  } finally {
    await other.app.close();
  }
});

test('mesma Idempotency-Key não debita duas vezes', async () => {
  const user = await api.newUser('Caio', 5000);
  const key = randomUUID();
  const first = await user.withdraw(pix('caio@teste.com'), key);
  const second = await user.withdraw(pix('caio@teste.com'), key);

  assert.equal(first.status, 201);
  assert.equal(second.status, 200);
  assert.equal(second.data.id, first.data.id);
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 3000);
});

test('saldo insuficiente retorna 402 e não mexe no saldo', async () => {
  const user = await api.newUser('Duda', 1500);
  const { status, data } = await user.withdraw(pix('duda@teste.com'));
  assert.equal(status, 402);
  assert.equal(data.error, 'insufficient_funds');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 1500);
});

test('dois saques ao mesmo tempo com saldo para um só: apenas um passa', async () => {
  const user = await api.newUser('Eli', 2000);
  const results = await Promise.all([
    user.withdraw(pix('eli@teste.com')),
    user.withdraw(pix('eli@teste.com')),
  ]);
  assert.deepEqual(results.map((r) => r.status).sort(), [201, 402]);
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 0);
});

test('Pix que falha depois devolve o saldo inteiro (inclusive a taxa)', async () => {
  const user = await api.newUser('Fabi', 5000);
  const { data } = await user.withdraw(pix('falha@teste.com'));
  await waitStatus(user, data.id, 'FAILED');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 5000);

  const types = (await user.get('/v1/ledger')).data.entries.map((e) => e.type);
  assert.deepEqual(types, ['refund', 'withdrawal', 'credit']);
});

test('recusa imediata do provedor devolve o saldo na hora', async () => {
  const user = await api.newUser('Gabi', 5000);
  const { status, data } = await user.withdraw(pix('recusa@teste.com'));
  assert.equal(status, 201);
  assert.equal(data.status, 'FAILED');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 5000);
});

test('timeout do provedor NÃO devolve o saldo (vai para REVIEW)', async () => {
  const user = await api.newUser('Hugo', 5000);
  const { data } = await user.withdraw(pix('timeout@teste.com'));
  assert.equal(data.status, 'REVIEW');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 3000);
});

test('valida valor mínimo, chave Pix e Idempotency-Key', async () => {
  const user = await api.newUser('Ivo', 5000);
  const tooSmall = await user.withdraw({ ...pix('ivo@teste.com'), amount_cents: 500 });
  assert.equal(tooSmall.data.error, 'amount_out_of_range');

  const badKey = await user.withdraw({ amount_cents: 2000, pix_key: '123', pix_key_type: 'CPF' });
  assert.equal(badKey.data.error, 'invalid_pix_key');

  const noIdem = await user.withdraw(pix('ivo@teste.com'), '');
  assert.equal(noIdem.data.error, 'idempotency_key_required');
});

test('rotas protegidas exigem autenticação', async () => {
  assert.equal((await api.call('GET', '/v1/balance')).status, 401);
  assert.equal((await api.call('GET', '/v1/balance', { headers: { authorization: 'Bearer errada' } })).status, 401);
  assert.equal((await api.call('GET', '/admin/revenue')).status, 401);
});

test('um usuário não enxerga o saque de outro', async () => {
  const a = await api.newUser('Jo', 5000);
  const b = await api.newUser('Kau', 5000);
  const { data } = await a.withdraw(pix('jo@teste.com'));
  assert.equal((await b.get(`/v1/withdrawals/${data.id}`)).status, 404);
});

test('webhook: token errado é rejeitado e evento repetido é ignorado', async () => {
  const slow = await makeApp({ MOCK_DELAY_MS: '600000' });
  try {
    const c = client(slow.base);
    const user = await c.newUser('Lia', 5000);
    const { data } = await user.withdraw(pix('lia@teste.com'));
    const externalId = slow.app.db
      .prepare('SELECT external_id FROM withdrawals WHERE id = ?')
      .get(data.id).external_id;

    const event = { eventId: 'evt-1', externalId, status: 'COMPLETED' };
    const bad = await c.call('POST', '/webhooks/mock', { body: event, headers: { 'x-webhook-token': 'errado' } });
    assert.equal(bad.status, 401);

    const headers = { 'x-webhook-token': 'mock-token' };
    const ok = await c.call('POST', '/webhooks/mock', { body: event, headers });
    assert.equal(ok.data.handled, true);
    const dup = await c.call('POST', '/webhooks/mock', { body: event, headers });
    assert.equal(dup.data.duplicate, true);

    assert.equal((await user.get(`/v1/withdrawals/${data.id}`)).data.status, 'COMPLETED');
  } finally {
    await slow.app.close();
  }
});

test('relatório de receita soma só saques concluídos', async () => {
  const fresh = await makeApp();
  try {
    const c = client(fresh.base);
    const user = await c.newUser('Mia', 10000);
    const ok1 = await user.withdraw(pix('mia1@teste.com'));
    const ok2 = await user.withdraw(pix('mia2@teste.com'));
    await user.withdraw(pix('falha@teste.com'));
    await waitStatus(user, ok1.data.id, 'COMPLETED');
    await waitStatus(user, ok2.data.id, 'COMPLETED');
    await sleep(150);

    const { data } = await c.admin('GET', '/admin/revenue');
    assert.equal(data.completed_withdrawals, 2);
    assert.equal(data.fees_collected_cents, 100);
    assert.equal(data.provider_cost_cents, 20);
    assert.equal(data.profit_cents, 80);
  } finally {
    await fresh.app.close();
  }
});

test('painel admin: lista usuários/saques e resolve saque em REVIEW', async () => {
  const user = await api.newUser('Nina', 5000);
  const { data } = await user.withdraw(pix('timeout@teste.com'));
  assert.equal(data.status, 'REVIEW');

  const users = (await api.admin('GET', '/admin/users')).data.users;
  assert.ok(users.some((u) => u.name === 'Nina'));
  const reviews = (await api.admin('GET', '/admin/withdrawals?status=REVIEW')).data.withdrawals;
  assert.ok(reviews.some((w) => w.id === data.id && w.user_name === 'Nina'));

  // ação inválida e saque que não está em revisão
  assert.equal((await api.admin('POST', `/admin/withdrawals/${data.id}/resolve`, { action: 'x' })).status, 400);

  const refund = await api.admin('POST', `/admin/withdrawals/${data.id}/resolve`, { action: 'refund' });
  assert.equal(refund.data.status, 'FAILED');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 5000);
  assert.equal((await api.admin('POST', `/admin/withdrawals/${data.id}/resolve`, { action: 'refund' })).status, 409);

  const second = await user.withdraw(pix('timeout@teste.com'));
  const done = await api.admin('POST', `/admin/withdrawals/${second.data.id}/resolve`, { action: 'complete' });
  assert.equal(done.data.status, 'COMPLETED');
  assert.equal((await user.get('/v1/balance')).data.balance_cents, 3000);
});

test('site: páginas servidas com cabeçalhos de segurança', async () => {
  for (const path of ['/', '/admin', '/app', '/style.css', '/common.js', '/admin.js', '/app.js', '/logo.svg', '/manifest.webmanifest']) {
    const res = await fetch(ctx.base + path);
    assert.equal(res.status, 200, path);
    assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  }
  assert.equal((await fetch(ctx.base + '/../package.json')).status, 404);
  assert.equal((await fetch(ctx.base + '/src/config.js')).status, 404);
});

test('taxa própria por cliente, bloqueio e nova chave', async () => {
  const user = await api.newUser('Otto', 10000);
  const set = await api.admin('POST', `/admin/users/${user.id}/fee`, { fee_cents: 100 });
  assert.equal(set.data.effective_fee_cents, 100);
  assert.equal((await user.get('/v1/fee')).data.fee_cents, 100);
  const w = await user.withdraw(pix('otto@teste.com'));
  assert.equal(w.data.fee_cents, 100);
  assert.equal(w.data.net_cents, 1900);

  assert.equal((await api.admin('POST', `/admin/users/${user.id}/fee`, { fee_cents: 99999 })).status, 400);
  const reset = await api.admin('POST', `/admin/users/${user.id}/fee`, { fee_cents: null });
  assert.equal(reset.data.effective_fee_cents, 50);

  await api.admin('POST', `/admin/users/${user.id}/block`, { blocked: true });
  const blocked = await user.withdraw(pix('otto@teste.com'));
  assert.equal(blocked.status, 403);
  assert.equal(blocked.data.error, 'account_blocked');
  await api.admin('POST', `/admin/users/${user.id}/block`, { blocked: false });
  assert.equal((await user.withdraw(pix('otto@teste.com'))).status, 201);

  const rotated = await api.admin('POST', `/admin/users/${user.id}/rotate-key`);
  assert.match(rotated.data.api_key, /^gw_/);
  assert.equal((await user.get('/v1/balance')).status, 401); // chave antiga morreu
  const res = await fetch(ctx.base + '/v1/balance', { headers: { authorization: `Bearer ${rotated.data.api_key}` } });
  assert.equal(res.status, 200);
});

test('CSV exporta saques e neutraliza fórmulas; relatório traz 7 dias', async () => {
  const user = await api.newUser('=cmd|calc', 5000);
  await user.withdraw(pix('csv@teste.com'));
  const res = await fetch(ctx.base + '/admin/withdrawals.csv', { headers: { 'x-admin-key': ADMIN } });
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /text\/csv/);
  const bytes = new Uint8Array(await res.arrayBuffer());
  assert.deepEqual([...bytes.slice(0, 3)], [0xef, 0xbb, 0xbf]); // BOM para o Excel abrir acentos
  const text = new TextDecoder('utf-8', { ignoreBOM: true }).decode(bytes).slice(1);
  assert.match(text, /^id,data_utc,cliente/);
  assert.ok(text.includes("'=cmd|calc"));
  assert.equal((await fetch(ctx.base + '/admin/withdrawals.csv')).status, 401);

  const { data } = await api.admin('GET', '/admin/revenue');
  assert.equal(data.daily.length, 7);
});

test('cliente: chaves salvas, limites, resumo e extrato CSV', async () => {
  const user = await api.newUser('Paula', 10000);
  const auth = (await api.admin('POST', `/admin/users/${user.id}/rotate-key`)).data.api_key;
  const call = (method, path, body) =>
    fetch(ctx.base + path, {
      method,
      headers: { authorization: `Bearer ${auth}`, 'content-type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    }).then(async (r) => ({ status: r.status, data: await r.json().catch(() => ({})) }));

  const saved = await call('POST', '/v1/pix-keys', { label: 'Minha conta', pix_key_type: 'EMAIL', pix_key: 'paula@teste.com' });
  assert.equal(saved.status, 201);
  assert.equal((await call('POST', '/v1/pix-keys', { label: 'Dup', pix_key_type: 'EMAIL', pix_key: 'paula@teste.com' })).status, 409);
  assert.equal((await call('POST', '/v1/pix-keys', { label: 'Ruim', pix_key_type: 'CPF', pix_key: '123' })).status, 400);
  assert.equal((await call('POST', '/v1/pix-keys', { label: '', pix_key_type: 'EMAIL', pix_key: 'a@b.co' })).status, 400);
  assert.equal((await call('GET', '/v1/pix-keys')).data.keys.length, 1);

  // outro cliente não consegue apagar a chave dela
  const other = await api.newUser('Quim');
  const otherKey = (await api.admin('POST', `/admin/users/${other.id}/rotate-key`)).data.api_key;
  const stolen = await fetch(ctx.base + `/v1/pix-keys/${saved.data.id}`, { method: 'DELETE', headers: { authorization: `Bearer ${otherKey}` } });
  assert.equal(stolen.status, 404);

  const w = await call('POST', '/v1/withdrawals', { amount_cents: 2000, pix_key: 'paula@teste.com', pix_key_type: 'EMAIL' });
  assert.equal(w.status, 400); // sem Idempotency-Key
  const ok = await fetch(ctx.base + '/v1/withdrawals', {
    method: 'POST',
    headers: { authorization: `Bearer ${auth}`, 'content-type': 'application/json', 'idempotency-key': randomUUID() },
    body: JSON.stringify({ amount_cents: 2000, pix_key: 'paula@teste.com', pix_key_type: 'EMAIL' }),
  });
  assert.equal(ok.status, 201);
  await sleep(150);

  const limits = (await call('GET', '/v1/limits')).data;
  assert.equal(limits.daily_used_cents, 2000);
  assert.equal(limits.daily_remaining_cents, limits.daily_limit_cents - 2000);
  const summary = (await call('GET', '/v1/summary')).data;
  assert.equal(summary.month.withdrawn_cents, 2000);
  assert.equal(summary.month.fees_paid_cents, 50);
  assert.equal(summary.all_time.withdrawals, 1);

  const csv = await fetch(ctx.base + '/v1/ledger.csv', { headers: { authorization: `Bearer ${auth}` } });
  assert.match(csv.headers.get('content-type'), /text\/csv/);
  assert.match(await csv.text(), /withdrawal,-20\.00/);

  assert.equal((await call('DELETE', `/v1/pix-keys/${saved.data.id}`)).status, 200);
  assert.equal((await call('GET', '/v1/pix-keys')).data.keys.length, 0);
});
