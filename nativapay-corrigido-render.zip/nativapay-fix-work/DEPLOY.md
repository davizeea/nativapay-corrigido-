# Colocar a NativaPay no ar

## 1. Seja realista sobre "grátis"

Para **testar** (modo `mock` ou sandbox do Asaas) dá para usar hospedagem grátis. Para **dinheiro de verdade**, não. Conferi as fontes em novembro de 2026:

| Plataforma | O que acontece no plano grátis |
|---|---|
| Render | O serviço **dorme após 15 min** sem uso e leva cerca de 1 min para acordar. O disco é **efêmero** (some ao reiniciar). O Postgres grátis **expira em 30 dias**. A própria Render diz para não usar em produção. |
| Fly.io | Não tem plano grátis (só teste de 7 dias) e exige cartão. |
| Railway | US$ 5 de crédito único para teste, depois cerca de US$ 1/mês. |

Por que isso importa aqui:
- A NativaPay guarda os saldos em um arquivo (SQLite). **Disco que apaga = saldos perdidos.**
- O Asaas **pausa a fila de avisos depois de 15 falhas seguidas**. Servidor dormindo = depósitos pagos que não entram no saldo até alguém reativar a fila (eles ficam guardados por até 14 dias).

**Recomendação:** para operar de verdade, use o plano pago mais barato com **disco persistente** (hoje na faixa de US$ 4 a 6 por mês; confira o preço atual no site de cada um). Para só experimentar, o grátis serve.

Fontes: [comparativo de planos grátis](https://flaviocopes.com/hosting-free-tiers/), [Node.js grátis em 2026](https://snapdeploy.dev/blog/deploy-nodejs-app-free-2026), [FAQ de webhooks do Asaas](https://docs.asaas.com/docs/faq-de-webhooks).

## 2. Variáveis de ambiente

Configure no painel da hospedagem (o arquivo `.env` não deve ir para o GitHub).

| Variável | Valor |
|---|---|
| `ADMIN_KEY` | uma chave longa e aleatória (mín. 16 caracteres) |
| `ADMIN_TOTP_SECRET` | gere com `npm run admin:2fa` (recomendado) |
| `FEE_CENTS` | `50` ou `100` |
| `PROVIDER_COST_CENTS` | quanto o provedor cobra por saque (para o cálculo de lucro) |
| `TRUST_PROXY` | `true` (hospedagem com proxy). Sem isso o bloqueio por tentativas enxerga todo mundo como um único IP. |
| `DB_PATH` | caminho **dentro do disco persistente**, ex.: `/data/nativapay.db` |
| `PROVIDER` | `mock` para testar, `asaas` para valer |
| `ASAAS_API_KEY`, `ASAAS_WEBHOOK_TOKEN`, `ASAAS_BASE_URL` | só com `PROVIDER=asaas` (veja o passo 4) |

## 3. Publicar

O projeto roda com `npm start` (Node 22.13 ou mais novo) e tem um `Dockerfile` pronto. Em qualquer plataforma o caminho é o mesmo:

1. Ponha o projeto em um repositório no GitHub.
2. Na hospedagem, crie um serviço web a partir do repositório (use o `Dockerfile`, ou "Node" com comando `npm start`).
3. **Anexe um disco/volume persistente** montado em `/data` e use `DB_PATH=/data/nativapay.db`.
4. Preencha as variáveis do passo 2 e publique. Abra `https://SEU-ENDERECO/health`: deve responder `{"ok":true,...}`.

> O `Dockerfile` não pôde ser construído aqui (o Docker deste ambiente estava sem o serviço ligado). Testei o servidor rodando só com os arquivos que ele copia e com as mesmas variáveis; se o build falhar na sua hospedagem, use "Node" com comando `npm start` no lugar.

### Pelo iPhone

Você consegue fazer tudo pelo Safari, mas o upload de pastas é o ponto chato. Um caminho possível:
1. Crie uma conta no GitHub e um repositório vazio.
2. Abra o repositório em um **Codespace** (botão *Code* > *Codespaces*). Se o menu vier cortado, use *Solicitar site para computador* no Safari.
3. No Codespace, envie o `nativapay.zip` (menu do Explorador > *Upload*) e, no terminal: `unzip nativapay.zip && cp -r nativapay/. . && rm -rf nativapay nativapay.zip && git add -A && git commit -m "NativaPay" && git push`.
4. Conecte o repositório na hospedagem (passo 3).

Não consegui testar o Codespace pelo iPhone. Se travar, é o único passo que vale pedir ajuda de alguém com computador.

## 4. Configurar o Asaas

1. Crie a conta e **teste primeiro no sandbox**: `ASAAS_BASE_URL=https://api-sandbox.asaas.com/v3`. Produção: `https://api.asaas.com/v3`.
2. Cadastre uma **chave Pix** na conta Asaas. Sem ela, o QR Code de cobrança vale só até 23:59 do mesmo dia ([docs](https://docs.asaas.com/docs/cobrancas-via-pix)).
3. Gere a chave de API e coloque em `ASAAS_API_KEY`. Invente um `ASAAS_WEBHOOK_TOKEN` (mín. 16 caracteres, diferente da chave de API).
4. No painel do Asaas, em Integrações > Webhooks, cadastre a URL `https://SEU-ENDERECO/webhooks/asaas` com o **mesmo token**, para estes eventos:
   - **Cobranças:** `PAYMENT_RECEIVED` (obrigatório: é ele que credita o saldo). Opcionais: `PAYMENT_DELETED`, `PAYMENT_REFUNDED`, `PAYMENT_PARTIALLY_REFUNDED`, `PAYMENT_CHARGEBACK_REQUESTED`. Estorno e contestação colocam o depósito em "Em revisão" para você conferir.
   - **Transferências:** `TRANSFER_DONE`, `TRANSFER_FAILED`, `TRANSFER_CANCELLED`.
   Se a tela do Asaas for diferente, o essencial é: URL, token e esses eventos.
5. O servidor responde HTTP 200 a qualquer evento, que é o que o Asaas exige ([docs](https://docs.asaas.com/docs/faq-de-webhooks)).
6. Sua conta pode exigir o [mecanismo de autorização de saques](https://docs.asaas.com/docs/mecanismo-para-validacao-de-transferencias-via-webhooks). Pergunte ao suporte do Asaas.

**O adaptador do Asaas foi testado só com chamadas simuladas, nunca contra o sandbox de verdade.** Faça os testes abaixo antes de qualquer dinheiro real.

## 5. Checklist antes de usar dinheiro real

No sandbox (`PROVIDER=asaas` com a URL de sandbox):
- [ ] Cliente gera um Pix de R$ 10 e o sandbox o marca como pago; o saldo entra sozinho.
- [ ] O mesmo evento reenviado não credita duas vezes.
- [ ] Saque com chave válida conclui; saque que falha devolve o saldo.
- [ ] `/admin` entra com chave + código 2FA.
- [ ] Baixei um backup pelo painel e abri o arquivo.
- [ ] Reiniciei o serviço e os saldos continuaram lá (prova que o disco persiste).

Já em produção, comece com valores pequenos.

## 6. Backups

- O servidor salva **um backup por dia** em `backups/` ao lado do banco e guarda os 7 mais novos (`BACKUP_EVERY_HOURS`, `BACKUP_KEEP`). Isso protege contra erro, **mas não contra perder o disco inteiro**.
- Por isso, **baixe o backup pelo painel** (`/admin` > Segurança) com frequência e guarde fora da hospedagem.
- Para restaurar: pare o serviço, troque o arquivo do banco pelo backup (mesmo nome de `DB_PATH`) e inicie de novo.

## 7. Segurança

- 2FA do admin ligado (`npm run admin:2fa`) e `ADMIN_KEY` longa. O 2FA usa o app Senhas do iPhone, Google Authenticator, Authy ou 1Password.
- Depois de 8 tentativas erradas (ajustável em `LOGIN_MAX_FAILS`) o IP fica bloqueado por 15 minutos.
- O CPF/CNPJ do cliente fica no banco em texto puro, porque o provedor exige. Trate o backup como dado pessoal (LGPD) e não o compartilhe.
- Só use HTTPS (as hospedagens já dão).

## 8. Limites que ainda existem

- **Estorno de depósito:** se o Asaas estornar um Pix que já virou saldo, o depósito vai para "Em revisão", mas o sistema **não desconta o saldo sozinho**. Hoje isso é decisão sua, fora do painel.
- **Um servidor só:** o banco é um arquivo. Não rode duas cópias ao mesmo tempo.
- **Regulação:** guardar saldo de terceiros pode exigir autorização do Banco Central. Converse com um contador antes de operar. Isto não é orientação jurídica.
