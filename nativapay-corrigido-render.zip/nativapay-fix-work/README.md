# NativaPay

Gateway de saques Pix com taxa fixa

API que recebe pedidos de saque, **cobra sua taxa (R$ 0,50 ou R$ 1,00)**, manda o valor líquido por Pix através de um provedor e mantém o extrato. Zero dependências (só Node.js 22.13+), banco SQLite embutido, custo R$ 0 para rodar em modo de teste.

## Rodar agora (grátis, sem provedor real)

```bash
cp .env.example .env      # edite ADMIN_KEY e FEE_CENTS (50 ou 100)
npm start
npm test                  # 28 testes automatizados
```

Com `PROVIDER=mock` nenhum dinheiro real se move. Chaves Pix de teste:

| Chave começa com | O que o mock simula |
|---|---|
| `falha...` | Pix aceito, depois falha → saldo devolvido |
| `recusa...` | Provedor recusa na hora → saldo devolvido |
| `timeout...` | Resultado desconhecido → status `REVIEW`, saldo **não** devolvido |
| qualquer outra | Sucesso (confirmado ~0,6 s depois) |

## Site (funciona no iPhone)

Com o servidor rodando, abra no navegador:

- `/` : página inicial
- `/app` : **área do cliente** (entra com a API key): saldo, pedir saque com prévia do valor líquido, meus saques e extrato
- `/admin` : **painel admin** (entra com `ADMIN_KEY`): lucro e receita, criar usuário (mostra a chave uma vez), creditar saldo, lista de usuários e saques, e fila de **saques em conferência** com os botões "O Pix saiu" / "Não saiu: devolver"

**Visual:** preto e branco, sempre escuro, mesmo que o celular esteja em modo claro.

**No painel admin:**
- gráfico de taxas dos últimos 7 dias e saldo total dos clientes
- **taxa própria por cliente** (ex.: cliente VIP paga R$ 0,50, os outros R$ 1,00; vazio = taxa padrão)
- **bloquear/desbloquear** saques de um cliente
- **gerar nova chave** de acesso (a antiga para de funcionar na hora)
- busca de clientes, filtro de saques por status e **exportar CSV**
- etiqueta "Modo teste" quando o provedor é o simulado

**Na área do cliente:**
- **chaves Pix salvas** (até 10, com apelido): escolha na lista em vez de digitar de novo; as chaves aparecem mascaradas
- **comprovante** de cada saque, com botão **Compartilhar** (folha de compartilhamento do iPhone) e **Repetir este saque**
- resumo do mês (sacado e taxas pagas) e **quanto ainda pode sacar hoje**
- aviso ao digitar se o valor passa do saldo ou do limite diário
- atalhos 25% / 50% / Tudo para preencher o valor
- extrato com filtro (entradas/saídas) e **exportar CSV**

**No iPhone:** abra o endereço no Safari, toque em Compartilhar e depois em *Adicionar à Tela de Início*. A NativaPay abre como app, com ícone próprio.

Sem dependências nem build: são arquivos em `public/` servidos pelo próprio servidor, com cabeçalhos de segurança (CSP). A sessão fica só na aba do navegador e some ao fechar.

## Fluxo de uso por API

```bash
# 1. Admin cria um usuário (a api_key aparece só uma vez)
curl -X POST localhost:3000/admin/users -H "x-admin-key: $ADMIN_KEY" \
  -H 'content-type: application/json' -d '{"name":"Maria"}'

# 2. Admin credita saldo (em produção isso vem de uma venda/Pix recebido)
curl -X POST localhost:3000/admin/users/1/credit -H "x-admin-key: $ADMIN_KEY" \
  -H 'content-type: application/json' -d '{"amount_cents":10000}'

# 3. Usuário pede saque de R$ 50,00 (5000 centavos)
curl -X POST localhost:3000/v1/withdrawals \
  -H "authorization: Bearer $API_KEY" -H 'idempotency-key: pedido-0001-abc' \
  -H 'content-type: application/json' \
  -d '{"amount_cents":5000,"pix_key":"maria@exemplo.com","pix_key_type":"EMAIL"}'
# → fee_cents: 50, net_cents: 4950 (ela recebe R$ 49,50)
```

## Endpoints

| Método | Rota | Auth | Descrição |
|---|---|---|---|
| GET | `/health` | — | Status |
| POST | `/webhooks/:provedor` | token do provedor | Recebe confirmações de Pix |
| POST | `/admin/users` | `x-admin-key` | Cria usuário e API key |
| POST | `/admin/users/:id/credit` | `x-admin-key` | Credita saldo |
| GET | `/admin/revenue` | `x-admin-key` | Taxas arrecadadas, custo do provedor e **lucro** |
| GET | `/admin/users`, `/admin/withdrawals?status=`, `/admin/withdrawals.csv` | `x-admin-key` | Listagens e exportação |
| POST | `/admin/users/:id/fee` · `/block` · `/rotate-key` | `x-admin-key` | `{"fee_cents":100}` ou `null` · `{"blocked":true}` · nova chave |
| POST | `/admin/withdrawals/:id/resolve` | `x-admin-key` | `{"action":"complete"\|"refund"}` para saques em `REVIEW` |
| GET | `/v1/fee` | Bearer | Taxa e limites |
| GET | `/v1/balance` | Bearer | Saldo |
| GET | `/v1/ledger` · `/v1/ledger.csv` | Bearer | Extrato (JSON e CSV) |
| GET | `/v1/limits` · `/v1/summary` | Bearer | Limite diário restante e resumo do mês |
| GET/POST | `/v1/pix-keys` · DELETE `/v1/pix-keys/:id` | Bearer | Chaves Pix salvas |
| POST | `/v1/withdrawals` | Bearer + `Idempotency-Key` | Pede saque |
| GET | `/v1/withdrawals` / `/:id` | Bearer | Lista / consulta |

Valores sempre em **centavos inteiros**.

## Como a taxa funciona

O usuário pede X; o saldo dele cai X; ele recebe **X − taxa**; a taxa é sua. Se o Pix falhar, **o valor inteiro volta** (taxa incluída). Sua receita só conta saques `COMPLETED`.

Configure `PROVIDER_COST_CENTS` com o que o provedor cobra por transferência: `/admin/revenue` mostra o lucro real (taxa − custo). **Se o custo do provedor for maior que a sua taxa, você perde dinheiro em cada saque.** Confira a tabela de preços atual antes de escolher R$ 0,50.

## Proteções já implementadas

- **Idempotência:** repetir a mesma requisição não debita duas vezes.
- **Transação atômica:** saldo reservado e saque registrado juntos; dois saques simultâneos não gastam o mesmo saldo.
- **Timeout ≠ falha:** se o provedor não responde, o saque vai para `REVIEW` e o saldo **não** é devolvido automaticamente (o Pix pode ter saído). Confira no painel do provedor.
- **Webhook:** token em tempo constante e deduplicação de eventos.
- **API keys** guardadas só como hash SHA-256; limites mínimo/máximo/diário; rate limit por IP.

## Depósito por Pix (adicionar saldo)

O cliente informa o valor (e o CPF/CNPJ na primeira vez), recebe um Pix **copia e cola** (e QR Code, quando o provedor devolve) e o saldo entra **sozinho** quando o pagamento é confirmado. Cada depósito credita uma única vez, mesmo se o aviso do provedor chegar repetido. Se o valor pago for diferente do cobrado, ou se houver estorno, o depósito vai para **Em revisão** no painel e nada é creditado/descontado automaticamente.

No modo teste (`mock`) o pagamento é simulado e confirma em alguns segundos.

## Segurança

- **2FA do admin** (opcional, recomendado): `npm run admin:2fa`. O login do `/admin` passa a pedir a chave e o código de 6 dígitos, e a chave pura deixa de valer.
- **Bloqueio por tentativas:** 8 erros seguidos (chave de admin, 2FA ou chave de cliente) bloqueiam o IP por 15 minutos.
- **Backup:** automático por dia (7 mais novos) e download pelo painel.

## Colocar no ar e configurar o Asaas

Veja o **[DEPLOY.md](DEPLOY.md)**: custos reais de hospedagem (grátis só serve para testar), variáveis, webhook do Asaas e checklist antes de usar dinheiro real.

## Antes de operar de verdade

- Esta API controla saldo, saque e depósito. O dinheiro real precisa estar na sua conta do provedor para o Pix sair.
- O adaptador do Asaas foi testado só com chamadas simuladas. Teste no sandbox antes.
- **Regulação:** guardar saldo de terceiros e repassar dinheiro pode exigir autorização do Banco Central. Converse com um contador. Isto não é orientação jurídica.
- Nunca versione o `.env`.
