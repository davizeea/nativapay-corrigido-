// Gera o segredo do 2FA do admin. Uso: npm run admin:2fa
import { generateSecret, otpauthUrl } from '../src/totp.js';

const secret = generateSecret();
console.log(`
NativaPay: verificação em duas etapas do admin

1) Adicione ao seu .env (ou às variáveis de ambiente da hospedagem):

   ADMIN_TOTP_SECRET=${secret}

2) No iPhone, abra o app Senhas (ou Google Authenticator, Authy, 1Password),
   escolha adicionar um código de verificação e use "inserir chave de configuração":

   Chave: ${secret}
   (ou o link otpauth: ${otpauthUrl(secret)})

3) Reinicie o servidor. A partir daí o login do /admin pede a chave + o código de 6 dígitos.

Guarde essa chave em lugar seguro. Quem a tiver gera os códigos.
`);
